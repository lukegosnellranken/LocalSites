-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 30, 2020 at 06:30 PM
-- Server version: 8.0.16
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `local`
--
CREATE DATABASE IF NOT EXISTS `local` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `local`;

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2020-04-07 23:04:27', '2020-04-07 23:04:27', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://st-charles-county-veterans-museum.local', 'yes'),
(2, 'home', 'http://st-charles-county-veterans-museum.local', 'yes'),
(3, 'blogname', 'St. Charles County Veterans Museum', 'yes'),
(4, 'blogdescription', 'Every veteran has a story', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'gosnellwebdesign@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'Y-m-d', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:112:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:9:\"events/?$\";s:25:\"index.php?post_type=event\";s:39:\"events/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=event&feed=$matches[1]\";s:34:\"events/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=event&feed=$matches[1]\";s:26:\"events/page/([0-9]{1,})/?$\";s:43:\"index.php?post_type=event&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:34:\"events/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"events/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"events/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"events/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"events/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"events/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:23:\"events/([^/]+)/embed/?$\";s:38:\"index.php?event=$matches[1]&embed=true\";s:27:\"events/([^/]+)/trackback/?$\";s:32:\"index.php?event=$matches[1]&tb=1\";s:47:\"events/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?event=$matches[1]&feed=$matches[2]\";s:42:\"events/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?event=$matches[1]&feed=$matches[2]\";s:35:\"events/([^/]+)/page/?([0-9]{1,})/?$\";s:45:\"index.php?event=$matches[1]&paged=$matches[2]\";s:42:\"events/([^/]+)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?event=$matches[1]&cpage=$matches[2]\";s:31:\"events/([^/]+)(?:/([0-9]+))?/?$\";s:44:\"index.php?event=$matches[1]&page=$matches[2]\";s:23:\"events/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:33:\"events/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:53:\"events/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"events/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"events/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:29:\"events/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=24&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:33:\"wp-phpmyadmin-extension/index.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'st-charles-veterans-theme', 'yes'),
(41, 'stylesheet', 'st-charles-veterans-theme', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '47018', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '5', 'yes'),
(84, 'page_on_front', '24', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'admin_email_lifespan', '1601852637', 'yes'),
(94, 'initial_db_version', '47018', 'yes'),
(95, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(96, 'fresh_site', '0', 'yes'),
(97, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(103, 'cron', 'a:7:{i:1588272032;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1588287874;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1588287881;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1588356736;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1588356738;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1588806275;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(104, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'nonce_key', 'U+5BR8$4m%icT<y3-ljO1?W^&gYUPk@K[6^k5A%+tLmcWx!Hg]RNme54Ltlq9uH2', 'no'),
(111, 'nonce_salt', '38=TJ.8QLUhXK+MXLbutqsOOR]7_fQQX<u9X7n[exyCAT2_>.qh+#iC17yCtHq(W', 'no'),
(112, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'recovery_keys', 'a:0:{}', 'yes'),
(122, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1588271278;s:7:\"checked\";a:1:{s:25:\"st-charles-veterans-theme\";s:3:\"1.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(124, 'theme_mods_twentytwenty', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1586810893;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}', 'yes'),
(130, '_transient_health-check-site-status-result', '{\"good\":\"9\",\"recommended\":\"7\",\"critical\":\"1\"}', 'yes'),
(147, 'can_compress_scripts', '1', 'no'),
(151, 'current_theme', 'St. Charles County Veterans Museum', 'yes'),
(152, 'theme_mods_st-charles-veterans-theme', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(153, 'theme_switched', '', 'yes'),
(192, 'WPLANG', '', 'yes'),
(193, 'new_admin_email', 'gosnellwebdesign@gmail.com', 'yes'),
(231, 'category_children', 'a:0:{}', 'yes'),
(237, 'recently_activated', 'a:0:{}', 'yes'),
(244, 'acf_version', '5.8.9', 'yes'),
(316, '_site_transient_timeout_browser_1570add4b3e660f27835bdca50814a71', '1588280900', 'no'),
(317, '_site_transient_browser_1570add4b3e660f27835bdca50814a71', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"81.0.4044.113\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(368, '_site_transient_timeout_browser_952637548dc3e67d2638455ee5804af8', '1588625009', 'no'),
(369, '_site_transient_browser_952637548dc3e67d2638455ee5804af8', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"81.0.4044.122\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(447, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.4.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.4.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.4.1\";s:7:\"version\";s:5:\"5.4.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1588271277;s:15:\"version_checked\";s:5:\"5.4.1\";s:12:\"translations\";a:0:{}}', 'no'),
(448, '_site_transient_timeout_browser_267bde5badd5f244b85b83450accebb5', '1588823460', 'no'),
(449, '_site_transient_browser_267bde5badd5f244b85b83450accebb5', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"81.0.4044.129\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(451, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1588271278;s:7:\"checked\";a:2:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.8.9\";s:33:\"wp-phpmyadmin-extension/index.php\";s:4:\"3.02\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:2:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.8.9\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.8.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"wp-phpmyadmin-extension/index.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/wp-phpmyadmin-extension\";s:4:\"slug\";s:23:\"wp-phpmyadmin-extension\";s:6:\"plugin\";s:33:\"wp-phpmyadmin-extension/index.php\";s:11:\"new_version\";s:4:\"3.02\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/wp-phpmyadmin-extension/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/wp-phpmyadmin-extension.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:76:\"https://ps.w.org/wp-phpmyadmin-extension/assets/icon-128x128.png?rev=2234810\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/wp-phpmyadmin-extension/assets/banner-1544x500.png?rev=2234812\";s:2:\"1x\";s:78:\"https://ps.w.org/wp-phpmyadmin-extension/assets/banner-772x250.png?rev=2234811\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(452, 'wp-phpmyadmin-extension', 'a:28:{s:16:\"randomCookieName\";s:20:\"pma_8FKvzlJCxDERGpgf\";s:17:\"randomCookieValue\";s:20:\"pma_FNYKuLAiOVQ81DHb\";s:18:\"RandomFolderSuffix\";s:24:\"_LM5t4uyJaSXN72pk1roYsWC\";s:20:\"manual_pma_login_url\";s:0:\"\";s:10:\"require_ip\";b:1;s:16:\"hide_phma_errors\";b:0;s:13:\"strip_slashes\";b:1;s:9:\"use_https\";b:1;s:12:\"is_localhost\";b:0;s:15:\"has_pro_version\";i:0;s:9:\"show_opts\";b:1;s:19:\"show_rating_message\";b:1;s:19:\"show_donation_popup\";b:1;s:12:\"display_tabs\";b:0;s:13:\"required_role\";s:15:\"install_plugins\";s:15:\"default_managed\";s:7:\"network\";s:17:\"menu_button_level\";s:8:\"mainmenu\";s:9:\"menu_icon\";s:137:\"http://st-charles-county-veterans-museum.local/wp-content/plugins/wp-phpmyadmin-extension//assets/media/menu_icon.png\" style=\"width:30px;\";s:16:\"menu_button_name\";s:13:\"WP-phpMyAdmin\";s:16:\"custom_opts_page\";s:0:\"\";s:4:\"name\";s:13:\"WP phpMyAdmin\";s:5:\"title\";s:61:\"<a href=\"https://puvox.software/wordpress/\">WP phpMyAdmin</a>\";s:7:\"version\";s:4:\"3.02\";s:18:\"first_install_date\";i:1588219177;s:16:\"last_update_time\";i:1588219177;s:12:\"last_updates\";a:0:{}s:12:\"last_version\";s:4:\"3.02\";s:15:\"ssl_error_shown\";i:1;}', 'yes'),
(453, 'wp-phpmyadmin-extension_transl_lastvers', '3.02', 'no'),
(456, '_site_transient_timeout_theme_roots', '1588273078', 'no'),
(457, '_site_transient_theme_roots', 'a:1:{s:25:\"st-charles-veterans-theme\";s:7:\"/themes\";}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_lock', '1587275952:1'),
(4, 7, '_edit_lock', '1588214250:1'),
(5, 9, '_edit_lock', '1588106854:1'),
(6, 11, '_edit_lock', '1588133603:1'),
(7, 13, '_edit_lock', '1588115114:1'),
(8, 15, '_edit_lock', '1587149733:1'),
(9, 17, '_edit_lock', '1588135994:1'),
(10, 20, '_edit_lock', '1588115198:1'),
(11, 22, '_edit_lock', '1588115085:1'),
(12, 24, '_edit_lock', '1587756062:1'),
(13, 26, '_edit_lock', '1587236752:1'),
(14, 1, '_wp_trash_meta_status', 'publish'),
(15, 1, '_wp_trash_meta_time', '1587252159'),
(16, 1, '_wp_desired_post_slug', 'hello-world'),
(17, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(18, 29, '_edit_lock', '1587756292:1'),
(23, 32, '_edit_last', '1'),
(24, 32, '_edit_lock', '1587269112:1'),
(25, 33, '_edit_last', '1'),
(26, 33, '_edit_lock', '1588021097:1'),
(27, 34, '_edit_last', '1'),
(28, 34, '_edit_lock', '1587267197:1'),
(29, 33, 'page_banner_subtitle', ''),
(30, 33, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(31, 33, 'page_banner_background_image', ''),
(32, 33, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(33, 37, '_edit_last', '1'),
(34, 37, '_edit_lock', '1588023142:1'),
(35, 33, 'event_date', '20200329'),
(36, 33, '_event_date', 'field_5e9bcceb9c5ee'),
(37, 32, 'event_date', '20200806'),
(38, 32, '_event_date', 'field_5e9bcceb9c5ee'),
(39, 32, 'page_banner_subtitle', ''),
(40, 32, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(41, 32, 'page_banner_background_image', ''),
(42, 32, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(43, 39, '_edit_last', '1'),
(44, 39, '_edit_lock', '1587657889:1'),
(45, 39, 'event_date', '20200402'),
(46, 39, '_event_date', 'field_5e9bcceb9c5ee'),
(47, 39, 'page_banner_subtitle', ''),
(48, 39, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(49, 39, 'page_banner_background_image', ''),
(50, 39, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(51, 5, '_edit_last', '1'),
(52, 5, 'page_banner_subtitle', ''),
(53, 5, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(54, 5, 'page_banner_background_image', ''),
(55, 5, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(56, 42, 'page_banner_subtitle', ''),
(57, 42, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(58, 42, 'page_banner_background_image', ''),
(59, 42, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(60, 44, '_edit_lock', '1587657188:1'),
(61, 44, '_edit_last', '1'),
(62, 44, 'page_banner_subtitle', ''),
(63, 44, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(64, 44, 'page_banner_background_image', ''),
(65, 44, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(66, 45, 'page_banner_subtitle', ''),
(67, 45, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(68, 45, 'page_banner_background_image', ''),
(69, 45, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(70, 24, '_edit_last', '1'),
(71, 24, 'page_banner_subtitle', ''),
(72, 24, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(73, 24, 'page_banner_background_image', ''),
(74, 24, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(75, 46, 'page_banner_subtitle', ''),
(76, 46, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(77, 46, 'page_banner_background_image', ''),
(78, 46, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(79, 47, 'page_banner_subtitle', ''),
(80, 47, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(81, 47, 'page_banner_background_image', ''),
(82, 47, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(85, 29, '_wp_old_date', '2020-04-18'),
(86, 29, '_edit_last', '1'),
(89, 29, 'page_banner_subtitle', ''),
(90, 29, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(91, 29, 'page_banner_background_image', ''),
(92, 29, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(93, 30, 'page_banner_subtitle', ''),
(94, 30, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(95, 30, 'page_banner_background_image', ''),
(96, 30, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(97, 48, '_edit_lock', '1587756516:1'),
(100, 48, '_edit_last', '1'),
(103, 48, 'page_banner_subtitle', ''),
(104, 48, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(105, 48, 'page_banner_background_image', ''),
(106, 48, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(107, 49, 'page_banner_subtitle', ''),
(108, 49, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(109, 49, 'page_banner_background_image', ''),
(110, 49, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(111, 48, '_wp_old_date', '2020-04-24'),
(114, 50, '_edit_lock', '1587756643:1'),
(117, 50, '_edit_last', '1'),
(120, 50, 'page_banner_subtitle', ''),
(121, 50, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(122, 50, 'page_banner_background_image', ''),
(123, 50, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(124, 51, 'page_banner_subtitle', ''),
(125, 51, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(126, 51, 'page_banner_background_image', ''),
(127, 51, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(128, 50, '_wp_old_date', '2020-04-24'),
(131, 52, '_edit_lock', '1587756638:1'),
(134, 52, '_edit_last', '1'),
(137, 52, 'page_banner_subtitle', ''),
(138, 52, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(139, 52, 'page_banner_background_image', ''),
(140, 52, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(141, 53, 'page_banner_subtitle', ''),
(142, 53, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(143, 53, 'page_banner_background_image', ''),
(144, 53, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(145, 52, '_wp_old_date', '2020-04-24'),
(148, 54, '_edit_lock', '1587756714:1'),
(151, 54, '_edit_last', '1'),
(154, 54, 'page_banner_subtitle', ''),
(155, 54, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(156, 54, 'page_banner_background_image', ''),
(157, 54, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(158, 55, 'page_banner_subtitle', ''),
(159, 55, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(160, 55, 'page_banner_background_image', ''),
(161, 55, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(162, 54, '_wp_old_date', '2020-04-24'),
(165, 56, '_edit_lock', '1587756948:1'),
(168, 56, '_edit_last', '1'),
(171, 56, 'page_banner_subtitle', ''),
(172, 56, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(173, 56, 'page_banner_background_image', ''),
(174, 56, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(175, 57, 'page_banner_subtitle', ''),
(176, 57, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(177, 57, 'page_banner_background_image', ''),
(178, 57, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(179, 56, '_wp_old_date', '2020-04-24'),
(182, 58, '_edit_lock', '1587757312:1'),
(185, 58, '_edit_last', '1'),
(188, 58, 'page_banner_subtitle', ''),
(189, 58, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(190, 58, 'page_banner_background_image', ''),
(191, 58, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(192, 59, 'page_banner_subtitle', ''),
(193, 59, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(194, 59, 'page_banner_background_image', ''),
(195, 59, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(196, 58, '_wp_old_date', '2020-04-24'),
(197, 58, '_pingme', '1'),
(198, 58, '_encloseme', '1'),
(199, 60, '_edit_lock', '1587757341:1'),
(200, 61, '_edit_last', '1'),
(201, 61, 'event_date', '20200321'),
(202, 61, '_event_date', 'field_5e9bcceb9c5ee'),
(203, 61, 'page_banner_subtitle', ''),
(204, 61, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(205, 61, 'page_banner_background_image', ''),
(206, 61, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(207, 61, '_edit_lock', '1588022620:1'),
(208, 39, '_wp_trash_meta_status', 'publish'),
(209, 39, '_wp_trash_meta_time', '1587757500'),
(210, 39, '_wp_desired_post_slug', 'test-event'),
(211, 32, '_wp_trash_meta_status', 'publish'),
(212, 32, '_wp_trash_meta_time', '1587757560'),
(213, 32, '_wp_desired_post_slug', 'st-charles-county-mayors-charity-ball-2020'),
(214, 62, '_edit_last', '1'),
(215, 62, '_edit_lock', '1588021289:1'),
(216, 62, 'event_date', '20200927'),
(217, 62, '_event_date', 'field_5e9bcceb9c5ee'),
(218, 62, 'page_banner_subtitle', ''),
(219, 62, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(220, 62, 'page_banner_background_image', ''),
(221, 62, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(222, 62, '_wp_trash_meta_status', 'publish'),
(223, 62, '_wp_trash_meta_time', '1588021436'),
(224, 62, '_wp_desired_post_slug', 'future-event'),
(225, 63, '_edit_last', '1'),
(226, 63, '_edit_lock', '1588023471:1'),
(227, 63, 'event_date', '20201126'),
(228, 63, '_event_date', 'field_5e9bcceb9c5ee'),
(229, 63, 'page_banner_subtitle', ''),
(230, 63, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(231, 63, 'page_banner_background_image', ''),
(232, 63, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(233, 64, '_edit_last', '1'),
(234, 64, '_edit_lock', '1588023735:1'),
(235, 64, 'event_date', '20200701'),
(236, 64, '_event_date', 'field_5e9bcceb9c5ee'),
(237, 64, 'page_banner_subtitle', ''),
(238, 64, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(239, 64, 'page_banner_background_image', ''),
(240, 64, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(241, 64, '_wp_trash_meta_status', 'publish'),
(242, 64, '_wp_trash_meta_time', '1588023883'),
(243, 64, '_wp_desired_post_slug', 'future-ii'),
(244, 63, '_wp_trash_meta_status', 'publish'),
(245, 63, '_wp_trash_meta_time', '1588023885'),
(246, 63, '_wp_desired_post_slug', 'future'),
(247, 66, '_edit_last', '1'),
(248, 66, '_edit_lock', '1588025122:1'),
(249, 66, 'event_date', '20200701'),
(250, 66, '_event_date', 'field_5e9bcceb9c5ee'),
(251, 66, 'page_banner_subtitle', ''),
(252, 66, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(253, 66, 'page_banner_background_image', ''),
(254, 66, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(255, 66, '_wp_trash_meta_status', 'publish'),
(256, 66, '_wp_trash_meta_time', '1588025266'),
(257, 66, '_wp_desired_post_slug', 'future-event-1'),
(258, 67, '_edit_last', '1'),
(259, 67, '_edit_lock', '1588025579:1'),
(260, 67, 'event_date', '20201119'),
(261, 67, '_event_date', 'field_5e9bcceb9c5ee'),
(262, 67, 'page_banner_subtitle', ''),
(263, 67, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(264, 67, 'page_banner_background_image', ''),
(265, 67, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(266, 67, '_wp_trash_meta_status', 'publish'),
(267, 67, '_wp_trash_meta_time', '1588025723'),
(268, 67, '_wp_desired_post_slug', 'future-thing'),
(269, 68, '_edit_last', '1'),
(270, 68, '_edit_lock', '1588028661:1'),
(271, 68, 'event_date', '20200806'),
(272, 68, '_event_date', 'field_5e9bcceb9c5ee'),
(273, 68, 'page_banner_subtitle', ''),
(274, 68, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(275, 68, 'page_banner_background_image', ''),
(276, 68, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(277, 68, '_wp_trash_meta_status', 'publish'),
(278, 68, '_wp_trash_meta_time', '1588028805'),
(279, 68, '_wp_desired_post_slug', 'future'),
(280, 9, '_edit_last', '1'),
(281, 9, 'page_banner_subtitle', ''),
(282, 9, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(283, 9, 'page_banner_background_image', ''),
(284, 9, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(285, 69, 'page_banner_subtitle', ''),
(286, 69, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(287, 69, 'page_banner_background_image', ''),
(288, 69, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(289, 70, 'page_banner_subtitle', ''),
(290, 70, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(291, 70, 'page_banner_background_image', ''),
(292, 70, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(293, 11, '_edit_last', '1'),
(294, 11, 'page_banner_subtitle', ''),
(295, 11, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(296, 11, 'page_banner_background_image', ''),
(297, 11, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(298, 71, 'page_banner_subtitle', ''),
(299, 71, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(300, 71, 'page_banner_background_image', ''),
(301, 71, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(302, 7, '_edit_last', '1'),
(303, 7, 'page_banner_subtitle', ''),
(304, 7, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(305, 7, 'page_banner_background_image', ''),
(306, 7, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(307, 72, 'page_banner_subtitle', ''),
(308, 72, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(309, 72, 'page_banner_background_image', ''),
(310, 72, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(311, 17, '_edit_last', '1'),
(312, 17, 'page_banner_subtitle', 'We need your help!'),
(313, 17, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(314, 17, 'page_banner_background_image', ''),
(315, 17, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(316, 73, 'page_banner_subtitle', ''),
(317, 73, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(318, 73, 'page_banner_background_image', ''),
(319, 73, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(320, 13, '_edit_last', '1'),
(321, 13, 'page_banner_subtitle', 'You can become one of our valued sponsors!'),
(322, 13, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(323, 13, 'page_banner_background_image', ''),
(324, 13, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(325, 74, 'page_banner_subtitle', ''),
(326, 74, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(327, 74, 'page_banner_background_image', ''),
(328, 74, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(329, 22, '_edit_last', '1'),
(330, 22, 'page_banner_subtitle', 'We give many thanks to our top donors'),
(331, 22, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(332, 22, 'page_banner_background_image', ''),
(333, 22, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(334, 75, 'page_banner_subtitle', ''),
(335, 75, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(336, 75, 'page_banner_background_image', ''),
(337, 75, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(338, 20, '_edit_last', '1'),
(339, 20, 'page_banner_subtitle', 'Please view our sponsorship packages'),
(340, 20, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(341, 20, 'page_banner_background_image', ''),
(342, 20, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(343, 76, 'page_banner_subtitle', 'We have many different levels of sponsorship available for you!'),
(344, 76, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(345, 76, 'page_banner_background_image', ''),
(346, 76, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(347, 77, 'page_banner_subtitle', 'You can become one of our valued sponsors!'),
(348, 77, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(349, 77, 'page_banner_background_image', ''),
(350, 77, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(351, 78, 'page_banner_subtitle', ''),
(352, 78, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(353, 78, 'page_banner_background_image', ''),
(354, 78, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(355, 79, '_wp_attached_file', '2020/04/home-depot.png'),
(356, 79, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:22:\"2020/04/home-depot.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"home-depot-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(357, 80, 'page_banner_subtitle', ''),
(358, 80, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(359, 80, 'page_banner_background_image', ''),
(360, 80, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(361, 81, 'page_banner_subtitle', 'We give many thanks to our top donors'),
(362, 81, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(363, 81, 'page_banner_background_image', ''),
(364, 81, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(365, 82, 'page_banner_subtitle', 'You can become one of our valued sponsors!'),
(366, 82, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(367, 82, 'page_banner_background_image', ''),
(368, 82, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(369, 83, 'page_banner_subtitle', 'Please view our sponsorship packages'),
(370, 83, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(371, 83, 'page_banner_background_image', ''),
(372, 83, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(373, 85, '_wp_attached_file', '2020/04/gallery1.png'),
(374, 85, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:475;s:6:\"height\";i:299;s:4:\"file\";s:20:\"2020/04/gallery1.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"gallery1-300x189.png\";s:5:\"width\";i:300;s:6:\"height\";i:189;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"gallery1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(375, 86, '_wp_attached_file', '2020/04/gallery2.png'),
(376, 86, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:475;s:6:\"height\";i:299;s:4:\"file\";s:20:\"2020/04/gallery2.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"gallery2-300x189.png\";s:5:\"width\";i:300;s:6:\"height\";i:189;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"gallery2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(377, 87, '_wp_attached_file', '2020/04/gallery3.png'),
(378, 87, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:475;s:6:\"height\";i:299;s:4:\"file\";s:20:\"2020/04/gallery3.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"gallery3-300x189.png\";s:5:\"width\";i:300;s:6:\"height\";i:189;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"gallery3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(379, 88, '_wp_attached_file', '2020/04/gallery4.png'),
(380, 88, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:475;s:6:\"height\";i:299;s:4:\"file\";s:20:\"2020/04/gallery4.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"gallery4-300x189.png\";s:5:\"width\";i:300;s:6:\"height\";i:189;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"gallery4-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(381, 89, 'page_banner_subtitle', ''),
(382, 89, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(383, 89, 'page_banner_background_image', ''),
(384, 89, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(385, 91, 'page_banner_subtitle', ''),
(386, 91, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(387, 91, 'page_banner_background_image', ''),
(388, 91, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(389, 92, '_wp_attached_file', '2020/04/MVIMG_20200425_115009-scaled.jpg'),
(390, 92, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:40:\"2020/04/MVIMG_20200425_115009-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_115009-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"MVIMG_20200425_115009-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_115009-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_115009-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_115009-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_115009-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"Pixel 3 XL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1587815409\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"4.44\";s:3:\"iso\";s:3:\"231\";s:13:\"shutter_speed\";s:8:\"0.041667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:25:\"MVIMG_20200425_115009.jpg\";}'),
(391, 93, '_wp_attached_file', '2020/04/MVIMG_20200425_112821-scaled.jpg'),
(392, 93, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:40:\"2020/04/MVIMG_20200425_112821-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112821-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"MVIMG_20200425_112821-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112821-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112821-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_112821-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_112821-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"Pixel 3 XL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1587814101\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"4.44\";s:3:\"iso\";s:3:\"230\";s:13:\"shutter_speed\";s:8:\"0.033363\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:25:\"MVIMG_20200425_112821.jpg\";}'),
(393, 94, '_wp_attached_file', '2020/04/MVIMG_20200425_112008-scaled.jpg'),
(394, 94, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:40:\"2020/04/MVIMG_20200425_112008-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112008-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"MVIMG_20200425_112008-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112008-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112008-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_112008-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_112008-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"Pixel 3 XL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1587813608\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"4.44\";s:3:\"iso\";s:2:\"55\";s:13:\"shutter_speed\";s:8:\"0.041667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:25:\"MVIMG_20200425_112008.jpg\";}'),
(395, 96, '_wp_attached_file', '2020/04/MVIMG_20200425_112349-scaled.jpg'),
(396, 96, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:40:\"2020/04/MVIMG_20200425_112349-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112349-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"MVIMG_20200425_112349-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112349-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112349-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_112349-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_112349-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"Pixel 3 XL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1587813829\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"4.44\";s:3:\"iso\";s:3:\"166\";s:13:\"shutter_speed\";s:8:\"0.041667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:25:\"MVIMG_20200425_112349.jpg\";}'),
(397, 97, 'page_banner_subtitle', ''),
(398, 97, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(399, 97, 'page_banner_background_image', ''),
(400, 97, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(401, 98, '_wp_attached_file', '2020/04/MVIMG_20200425_111710-scaled.jpg'),
(402, 98, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:40:\"2020/04/MVIMG_20200425_111710-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_111710-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"MVIMG_20200425_111710-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_111710-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_111710-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_111710-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_111710-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"Pixel 3 XL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1587813430\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"4.44\";s:3:\"iso\";s:2:\"90\";s:13:\"shutter_speed\";s:8:\"0.016703\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:25:\"MVIMG_20200425_111710.jpg\";}'),
(403, 99, 'page_banner_subtitle', ''),
(404, 99, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(405, 100, '_wp_attached_file', '2020/04/MVIMG_20200425_112520-scaled.jpg'),
(406, 99, 'page_banner_background_image', ''),
(407, 99, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(408, 100, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:40:\"2020/04/MVIMG_20200425_112520-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112520-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"MVIMG_20200425_112520-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112520-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"MVIMG_20200425_112520-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_112520-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:35:\"MVIMG_20200425_112520-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"Pixel 3 XL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1587813920\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"4.44\";s:3:\"iso\";s:3:\"126\";s:13:\"shutter_speed\";s:8:\"0.041667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:25:\"MVIMG_20200425_112520.jpg\";}'),
(409, 102, 'page_banner_subtitle', ''),
(410, 102, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(411, 102, 'page_banner_background_image', ''),
(412, 102, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(413, 103, '_wp_attached_file', '2020/04/volunteer.png'),
(414, 103, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:514;s:4:\"file\";s:21:\"2020/04/volunteer.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"volunteer-292x300.png\";s:5:\"width\";i:292;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"volunteer-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(415, 104, 'page_banner_subtitle', ''),
(416, 104, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(417, 104, 'page_banner_background_image', ''),
(418, 104, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(419, 105, 'page_banner_subtitle', 'We need your help!'),
(420, 105, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(421, 105, 'page_banner_background_image', ''),
(422, 105, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(423, 7, '_oembed_32f1f35053687120c0f28e944657969a', '<iframe title=\"St. Charles County Veterans Museum Opening | O&#039;Fallon Matters\" width=\"500\" height=\"281\" src=\"https://www.youtube.com/embed/KiCKlzn4XU8?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(424, 7, '_oembed_time_32f1f35053687120c0f28e944657969a', '1588136441'),
(425, 7, '_oembed_283bebafd8f4e9420bebd315915d1bb2', '<iframe title=\"St. Charles County Veterans Museum | O&#039;Fallon Matters\" width=\"500\" height=\"281\" src=\"https://www.youtube.com/embed/nS9zt9xMHCM?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(426, 7, '_oembed_time_283bebafd8f4e9420bebd315915d1bb2', '1588136441'),
(427, 107, 'page_banner_subtitle', ''),
(428, 107, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(429, 107, 'page_banner_background_image', ''),
(430, 107, '_page_banner_background_image', 'field_5e9bc5ea8366d'),
(431, 108, 'page_banner_subtitle', ''),
(432, 108, '_page_banner_subtitle', 'field_5e9bc5dc8366c'),
(433, 108, 'page_banner_background_image', ''),
(434, 108, '_page_banner_background_image', 'field_5e9bc5ea8366d');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2020-04-07 23:04:27', '2020-04-07 23:04:27', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2020-04-18 23:22:39', '2020-04-18 23:22:39', '', 0, 'http://st-charles-county-veterans-museum.local/?p=1', 0, 'post', '', 1),
(2, 1, '2020-04-07 23:04:27', '2020-04-07 23:04:27', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://st-charles-county-veterans-museum.local/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2020-04-07 23:04:27', '2020-04-07 23:04:27', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=2', 0, 'page', '', 0),
(3, 1, '2020-04-07 23:04:27', '2020-04-07 23:04:27', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://st-charles-county-veterans-museum.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2020-04-07 23:04:27', '2020-04-07 23:04:27', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=3', 0, 'page', '', 0),
(5, 1, '2020-04-17 18:55:01', '2020-04-17 18:55:01', '<!-- wp:paragraph -->\n<p>News page content</p>\n<!-- /wp:paragraph -->', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2020-04-19 06:01:11', '2020-04-19 06:01:11', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=5', 0, 'page', '', 0),
(6, 1, '2020-04-17 18:55:01', '2020-04-17 18:55:01', '<!-- wp:paragraph -->\n<p>News page content</p>\n<!-- /wp:paragraph -->', 'News', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2020-04-17 18:55:01', '2020-04-17 18:55:01', '', 5, 'http://st-charles-county-veterans-museum.local/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2020-04-17 18:56:29', '2020-04-17 18:56:29', '<!-- wp:paragraph -->\n<p><strong>Below are some videos we have compiled! Watch and enjoy!</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:core-embed/youtube {\"url\":\"https://www.youtube.com/watch?v=KiCKlzn4XU8\\u0026feature=emb_logo\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed-youtube wp-block-embed is-type-video is-provider-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=KiCKlzn4XU8&amp;feature=emb_logo\n</div></figure>\n<!-- /wp:core-embed/youtube --></div></div>\n<!-- /wp:group --></div></div>\n<!-- /wp:group -->\n\n<!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"></div></div>\n<!-- /wp:group --></div></div>\n<!-- /wp:group -->\n\n<!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:core-embed/youtube {\"url\":\"https://www.youtube.com/watch?v=nS9zt9xMHCM\\u0026feature=emb_logo\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed-youtube wp-block-embed is-type-video is-provider-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=nS9zt9xMHCM&amp;feature=emb_logo\n</div></figure>\n<!-- /wp:core-embed/youtube --></div></div>\n<!-- /wp:group -->', 'Videos', '', 'publish', 'closed', 'closed', '', 'videos', '', '', '2020-04-29 05:03:06', '2020-04-29 05:03:06', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=7', 0, 'page', '', 0),
(8, 1, '2020-04-17 18:56:29', '2020-04-17 18:56:29', '<!-- wp:paragraph -->\n<p>Videos page</p>\n<!-- /wp:paragraph -->', 'Videos', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2020-04-17 18:56:29', '2020-04-17 18:56:29', '', 7, 'http://st-charles-county-veterans-museum.local/7-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2020-04-17 18:56:49', '2020-04-17 18:56:49', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>A museum that honors the story of every veteran that has ever lived in St. Charles County.&nbsp; That’s a tall order! We need your help!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The <em>St. Charles County Veterans Museum is a 501C.3 Non-Profit</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>To make a monetary donation to help support the museum please click on the link below.</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are looking to donate items to the St. Charles County Veterans Museum… Every one of us has a family member, a friend, a loved one who served in the military and many of us have memorabilia from their service to our country.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We are not certain we can part with it, but we don’t want to see it lost or forgotten. Wouldn’t it be wonderful if it could be shared with other veterans, and see it be part of the story with other St. Charles County Veterans. Maybe your family was born in St. Charles County but moved away, or they only retired here? If that veterans ever lived in St. Charles County, this museum is the place for his memories. If you would like to discuss how donate items to the museum, or if you want to share a story with us, please use the box below.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The St. Charles County Veterans Commission Committee opened the SAINT CHARLES COUNTY VETERANS MUSEUM IN THE SPRING OF 2019.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are interested in donating items, please contact us by email at&nbsp;<a href=\"mailto:%20info@stcharlescountyveteransmuseum.com\">info@stcharlescountyveteransmuseum.com</a><br>or call us at 636-294-2657 today.</p>\n<!-- /wp:paragraph -->', 'Donate', '', 'publish', 'closed', 'closed', '', 'donate', '', '', '2020-04-28 20:48:18', '2020-04-28 20:48:18', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=9', 0, 'page', '', 0),
(10, 1, '2020-04-17 18:56:49', '2020-04-17 18:56:49', '<!-- wp:paragraph -->\n<p>Donate page</p>\n<!-- /wp:paragraph -->', 'Donate', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2020-04-17 18:56:49', '2020-04-17 18:56:49', '', 9, 'http://st-charles-county-veterans-museum.local/9-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2020-04-17 18:57:13', '2020-04-17 18:57:13', '<!-- wp:paragraph -->\n<p>Below are some pictures of our gallery and displays. We are always on the lookout for new items to display from St. Charles County veterans. The museum also works to rotate items to have different displays throughout the year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to become a sponsor of a display as well, your name and/or business logo will be prominently displayed.&nbsp;<a href=\"http://stcharlescountyveteransmuseum.org/contact/index.html\">Contact us today</a>!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"ids\":[88,85,86,87,92,93,94,96,98,100],\"columns\":2,\"align\":\"center\"} -->\n<figure class=\"wp-block-gallery aligncenter columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4-300x189.png\" alt=\"\" data-id=\"88\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery4/\" class=\"wp-image-88\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1-300x189.png\" alt=\"\" data-id=\"85\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery1/\" class=\"wp-image-85\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2-300x189.png\" alt=\"\" data-id=\"86\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery2/\" class=\"wp-image-86\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3-300x189.png\" alt=\"\" data-id=\"87\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery3/\" class=\"wp-image-87\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_115009-1024x768.jpg\" alt=\"\" data-id=\"92\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_115009/\" class=\"wp-image-92\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112821-1024x768.jpg\" alt=\"\" data-id=\"93\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112821/\" class=\"wp-image-93\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112008-1024x768.jpg\" alt=\"\" data-id=\"94\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112008/\" class=\"wp-image-94\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112349-1024x768.jpg\" alt=\"\" data-id=\"96\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112349/\" class=\"wp-image-96\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_111710-1024x768.jpg\" alt=\"\" data-id=\"98\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_111710-scaled.jpg\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_111710/\" class=\"wp-image-98\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112520-1024x768.jpg\" alt=\"\" data-id=\"100\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112520-scaled.jpg\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112520/\" class=\"wp-image-100\"/></figure></li></ul></figure>\n<!-- /wp:gallery -->', 'Gallery', '', 'publish', 'closed', 'closed', '', 'gallery', '', '', '2020-04-29 04:11:00', '2020-04-29 04:11:00', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=11', 0, 'page', '', 0),
(12, 1, '2020-04-17 18:57:13', '2020-04-17 18:57:13', '<!-- wp:paragraph -->\n<p>Gallery page</p>\n<!-- /wp:paragraph -->', 'Gallery', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2020-04-17 18:57:13', '2020-04-17 18:57:13', '', 11, 'http://st-charles-county-veterans-museum.local/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2020-04-17 18:57:34', '2020-04-17 18:57:34', '<!-- wp:paragraph -->\n<p>Plans for a museum that honored all Veterans was a dream of Ralph Barrale (1924-2018) when he gathered a planning team, and secured a lease from the City of O’Fallon, Missouri at 410 East Elm Street.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The former City Annex has been transformed by a great team of volunteers. This 501C.3 not-for-profit Museum will feature the stories of all Veterans that ever served and who ever lived in St. Charles County.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Their mission is “<em>Inspiring, informing and engaging the residents of St. Charles County to honor the memories of County Veterans who served the United States of America with patriotic valor</em>” and creating a museum experience for young and old, veterans and patriots that truly honors our veterans. Here our military community will feel welcome, our children and grandchildren will engage, and our community connect. We welcome you and invite you to participate and join us in our mission.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Would you like to hear more? Please contact us by calling 636-294-2657 or email us at&nbsp;<a href=\"mailto:info@stcharlescountyveteransmuseum.com\" target=\"_blank\" rel=\"noreferrer noopener\">info@stcharlescountyveteransmuseum.com</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We welcome any size of contribution and will provide an acknowledgement and opportunity for everyone to show how they have helped make this museum a reality.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Special thank you to Home Depot for the help in making the St. Charles County Veterans Museum a reality!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Sponsors', '', 'publish', 'closed', 'closed', '', 'sponsors', '', '', '2020-04-28 23:05:13', '2020-04-28 23:05:13', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=13', 0, 'page', '', 0),
(14, 1, '2020-04-17 18:57:34', '2020-04-17 18:57:34', '<!-- wp:paragraph -->\n<p>Sponsors page</p>\n<!-- /wp:paragraph -->', 'Sponsors', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2020-04-17 18:57:34', '2020-04-17 18:57:34', '', 13, 'http://st-charles-county-veterans-museum.local/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2020-04-17 18:57:57', '2020-04-17 18:57:57', '<!-- wp:paragraph -->\n<p>Stories page</p>\n<!-- /wp:paragraph -->', 'Stories', '', 'publish', 'closed', 'closed', '', 'stories', '', '', '2020-04-17 18:57:57', '2020-04-17 18:57:57', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=15', 0, 'page', '', 0),
(16, 1, '2020-04-17 18:57:57', '2020-04-17 18:57:57', '<!-- wp:paragraph -->\n<p>Stories page</p>\n<!-- /wp:paragraph -->', 'Stories', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2020-04-17 18:57:57', '2020-04-17 18:57:57', '', 15, 'http://st-charles-county-veterans-museum.local/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2020-04-17 18:58:16', '2020-04-17 18:58:16', '<!-- wp:paragraph -->\n<p>Would you like to get involved with some of the most dedicated people in St. Charles County?<strong></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to join the volunteers working to make the St. Charles County Veterans Museum a reality, then we would like to hear from you! You don’t need to be a Veteran, we love Patriots too!&nbsp; Whether it is stuffing envelopes, building exhibits, helping with the Gift Shop, talking to groups, working on the gardens, or maybe you have ideas we haven’t even thought of yet! We want to hear from you!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You can either email us at&nbsp;<a href=\"mailto:info@stcharlescountyveteransmuseum.com\" target=\"_blank\" rel=\"noreferrer noopener\">info@stcharlescountyveteransmuseum.com</a>&nbsp;or call 636-294-2657 or fill out the form below!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":103,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/volunteer.png\" alt=\"\" class=\"wp-image-103\"/></figure>\n<!-- /wp:image -->', 'Volunteers', '', 'publish', 'closed', 'closed', '', 'volunteers', '', '', '2020-04-29 04:54:18', '2020-04-29 04:54:18', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=17', 0, 'page', '', 0),
(18, 1, '2020-04-17 18:58:16', '2020-04-17 18:58:16', '<!-- wp:paragraph -->\n<p>Volunteers page</p>\n<!-- /wp:paragraph -->', 'Volunteers', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-04-17 18:58:16', '2020-04-17 18:58:16', '', 17, 'http://st-charles-county-veterans-museum.local/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2020-04-17 19:05:08', '2020-04-17 19:05:08', '<!-- wp:paragraph -->\n<p>Donate page </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque et convallis risus, at commodo odio. Maecenas et dolor nec eros interdum commodo in eget odio. Ut et nibh ultricies, efficitur lectus vel, luctus tellus. Quisque mattis tellus id congue suscipit. Aenean in est id orci lacinia gravida. Duis vehicula varius malesuada. Nullam at nisl magna. Mauris quam nulla, volutpat nec sagittis ut, egestas nec augue. Curabitur vitae ipsum enim. Morbi vitae nunc volutpat, porta magna placerat, interdum eros. Suspendisse et varius dui. Fusce tempor eu erat in rhoncus. Suspendisse placerat purus vel purus vulputate, quis mollis ligula commodo. Maecenas sed interdum magna. Proin dapibus, lectus vel pretium pellentesque, risus nulla interdum eros, at sollicitudin tortor risus ut risus. Proin tempus luctus sodales.</p>\n<!-- /wp:paragraph -->', 'Donate', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2020-04-17 19:05:08', '2020-04-17 19:05:08', '', 9, 'http://st-charles-county-veterans-museum.local/9-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2020-04-18 06:09:20', '2020-04-18 06:09:20', '<!-- wp:paragraph -->\n<p>Sponsorship packages</p>\n<!-- /wp:paragraph -->', 'Packages', '', 'publish', 'closed', 'closed', '', 'packages', '', '', '2020-04-28 23:05:54', '2020-04-28 23:05:54', '', 13, 'http://st-charles-county-veterans-museum.local/?page_id=20', 0, 'page', '', 0),
(21, 1, '2020-04-18 06:09:20', '2020-04-18 06:09:20', '<!-- wp:paragraph -->\n<p>Sponsorship packages</p>\n<!-- /wp:paragraph -->', 'Packages', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2020-04-18 06:09:20', '2020-04-18 06:09:20', '', 20, 'http://st-charles-county-veterans-museum.local/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2020-04-18 06:11:00', '2020-04-18 06:11:00', '<!-- wp:paragraph -->\n<p><strong>Special thank you to Home Depot for the help in making the St. Charles County Veterans Museum a reality!</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"align\":\"center\",\"id\":79,\"sizeSlug\":\"large\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/home-depot.png\" alt=\"\" class=\"wp-image-79\"/></figure></div>\n<!-- /wp:image -->', 'Thank You!', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2020-04-28 23:04:42', '2020-04-28 23:04:42', '', 13, 'http://st-charles-county-veterans-museum.local/?page_id=22', 0, 'page', '', 0),
(23, 1, '2020-04-18 06:11:00', '2020-04-18 06:11:00', '<!-- wp:paragraph -->\n<p>page content</p>\n<!-- /wp:paragraph -->', 'Thank You!', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2020-04-18 06:11:00', '2020-04-18 06:11:00', '', 22, 'http://st-charles-county-veterans-museum.local/22-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2020-04-18 19:08:03', '2020-04-18 19:08:03', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p></p></blockquote>\n<!-- /wp:quote -->', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2020-04-24 19:00:22', '2020-04-24 19:00:22', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=24', 0, 'page', '', 0),
(25, 1, '2020-04-18 19:08:03', '2020-04-18 19:08:03', '', 'Home', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2020-04-18 19:08:03', '2020-04-18 19:08:03', '', 24, 'http://st-charles-county-veterans-museum.local/24-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2020-04-18 19:08:15', '2020-04-18 19:08:15', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2020-04-18 19:08:15', '2020-04-18 19:08:15', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=26', 0, 'page', '', 0),
(27, 1, '2020-04-18 19:08:15', '2020-04-18 19:08:15', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2020-04-18 19:08:15', '2020-04-18 19:08:15', '', 26, 'http://st-charles-county-veterans-museum.local/26-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2020-04-18 23:22:39', '2020-04-18 23:22:39', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2020-04-18 23:22:39', '2020-04-18 23:22:39', '', 1, 'http://st-charles-county-veterans-museum.local/1-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2019-07-12 23:23:21', '2019-07-12 23:23:21', '<!-- wp:paragraph -->\n<p>Per State Representative Nick Schroer via Facebook on 7-12-2019</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yesterday a very important piece of legislation was signed into law by Governor Mike Parson. House Bill 499, sponsored by my friend Representative Aaron Griesheimer, which protects workers on roadways from being struck, included my amendment renaming a portion of Interstate 70 after our late friend and American hero Ralph Barrale Sr.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You all know how Ralph as a young man stormed the beaches of Normandy in WWII under General Patton, liberated Dachau, and many other events proudly serving the United States. You all know Ralph’s impact on our state and county after he came home from serving in WWII.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ralph gave his life to serving, and this small token of appreciation will show Missouri that we are all proud to once call him a friend. Please visit the The St. Charles County Veterans Museum if you would like to learn more about Ralph and other St. Charles County veterans here in #HouseDistrict107</p>\n<!-- /wp:paragraph -->', 'Portion of Highway 70 Named After Ralph Barrale', '', 'publish', 'open', 'open', '', 'portion-of-highway-70-named-after-ralph-barrale', '', '', '2020-04-24 19:26:46', '2020-04-24 19:26:46', '', 0, 'http://st-charles-county-veterans-museum.local/?p=29', 0, 'post', '', 0),
(30, 1, '2020-04-18 23:23:21', '2020-04-18 23:23:21', '<!-- wp:paragraph -->\n<p>Per State Representative Nick Schroer via Facebook on 7-12-2019</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Yesterday a very important piece of legislation was signed into law by Governor Mike Parson. House Bill 499, sponsored by my friend Representative Aaron Griesheimer, which protects workers on roadways from being struck, included my amendment renaming a portion of Interstate 70 after our late friend and American hero Ralph Barrale Sr.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You all know how Ralph as a young man stormed the beaches of Normandy in WWII under General Patton, liberated Dachau, and many other events proudly serving the United States. You all know Ralph’s impact on our state and county after he came home from serving in WWII.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ralph gave his life to serving, and this small token of appreciation will show Missouri that we are all proud to once call him a friend. Please visit the The St. Charles County Veterans Museum if you would like to learn more about Ralph and other St. Charles County veterans here in #HouseDistrict107</p>\n<!-- /wp:paragraph -->', 'Portion of Highway 70 Named After Ralph Barrale', '', 'inherit', 'closed', 'closed', '', '29-revision-v1', '', '', '2020-04-18 23:23:21', '2020-04-18 23:23:21', '', 29, 'http://st-charles-county-veterans-museum.local/29-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2020-04-19 02:32:53', '2020-04-19 02:32:53', '<!-- wp:paragraph -->\n<p>News page content</p>\n<!-- /wp:paragraph -->', 'News & Events', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2020-04-19 02:32:53', '2020-04-19 02:32:53', '', 5, 'http://st-charles-county-veterans-museum.local/5-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2020-04-19 02:46:43', '2020-04-19 02:46:43', 'St Charles County Mayors Charity Ball will be held on Saturday, March 21!\r\n\r\nFor more information, click below to download the PDF flyer.\r\n\r\n&nbsp;\r\n\r\nProceeds from the event will help support the St. Charles County Veterans Museum.\r\n\r\nCall or email us. The museum is always looking for sponsors, donors, artifacts, memorabilia, veterans stories and volunteers. For more information on the museum, contact <a class=\"body2\" href=\"mailto:info@stcharlescountyveteransmuseum.com\">info@stcharlescountyveteransmuseum.com</a> or call 636-400-7698.', 'St. Charles County Mayors Charity Ball 2020', '', 'trash', 'closed', 'closed', '', 'st-charles-county-mayors-charity-ball-2020__trashed', '', '', '2020-04-24 19:46:00', '2020-04-24 19:46:00', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=32', 0, 'event', '', 0),
(33, 1, '2020-04-19 02:47:53', '2020-04-19 02:47:53', 'Be sure to join us at the St. Charles County Veterans Museum on Sunday, March 29 for the Vietnam War Veterans Remembrance Day.\r\n\r\nFor more information, click below to download the PDF flyer.', 'Vietnam War Veterans Remembrance Day', '', 'publish', 'closed', 'closed', '', 'vietnam-war-veterans-remembrance-day', '', '', '2020-04-24 19:44:48', '2020-04-24 19:44:48', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=33', 0, 'event', '', 0),
(34, 1, '2020-04-19 03:31:51', '2020-04-19 03:31:51', 'a:7:{s:8:\"location\";a:2:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}i:1;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"!=\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Page Banner', 'page-banner', 'publish', 'closed', 'closed', '', 'group_5e9bc5d2603cc', '', '', '2020-04-19 03:31:51', '2020-04-19 03:31:51', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=acf-field-group&#038;p=34', 0, 'acf-field-group', '', 0),
(35, 1, '2020-04-19 03:31:51', '2020-04-19 03:31:51', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Page Banner Subtitle', 'page_banner_subtitle', 'publish', 'closed', 'closed', '', 'field_5e9bc5dc8366c', '', '', '2020-04-19 03:31:51', '2020-04-19 03:31:51', '', 34, 'http://st-charles-county-veterans-museum.local/?post_type=acf-field&p=35', 0, 'acf-field', '', 0),
(36, 1, '2020-04-19 03:31:51', '2020-04-19 03:31:51', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Page Banner Background Image', 'page_banner_background_image', 'publish', 'closed', 'closed', '', 'field_5e9bc5ea8366d', '', '', '2020-04-19 03:31:51', '2020-04-19 03:31:51', '', 34, 'http://st-charles-county-veterans-museum.local/?post_type=acf-field&p=36', 1, 'acf-field', '', 0),
(37, 1, '2020-04-19 04:02:11', '2020-04-19 04:02:11', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"event\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Event Date', 'event-date', 'publish', 'closed', 'closed', '', 'group_5e9bcc0aa0ba4', '', '', '2020-04-27 21:27:38', '2020-04-27 21:27:38', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=acf-field-group&#038;p=37', 0, 'acf-field-group', '', 0),
(38, 1, '2020-04-19 04:02:12', '2020-04-19 04:02:12', 'a:8:{s:4:\"type\";s:11:\"date_picker\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:14:\"display_format\";s:5:\"m/d/Y\";s:13:\"return_format\";s:5:\"d/m/Y\";s:9:\"first_day\";i:1;}', 'Event Date', 'event_date', 'publish', 'closed', 'closed', '', 'field_5e9bcceb9c5ee', '', '', '2020-04-27 21:27:38', '2020-04-27 21:27:38', '', 37, 'http://st-charles-county-veterans-museum.local/?post_type=acf-field&#038;p=38', 0, 'acf-field', '', 0),
(39, 1, '2020-04-19 04:07:57', '2020-04-19 04:07:57', 'testing', 'Test Event', '', 'trash', 'closed', 'closed', '', 'test-event__trashed', '', '', '2020-04-24 19:45:00', '2020-04-24 19:45:00', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=39', 0, 'event', '', 0),
(42, 1, '2020-04-19 05:59:26', '2020-04-19 05:59:26', '<!-- wp:paragraph -->\n<p>News page content</p>\n<!-- /wp:paragraph -->', 'News', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2020-04-19 05:59:26', '2020-04-19 05:59:26', '', 5, 'http://st-charles-county-veterans-museum.local/5-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2020-04-23 15:52:23', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-04-23 15:52:23', '0000-00-00 00:00:00', '', 0, 'http://st-charles-county-veterans-museum.local/?p=43', 0, 'post', '', 0),
(44, 1, '2020-04-23 15:53:05', '2020-04-23 15:53:05', '', 'Past Events', '', 'publish', 'closed', 'closed', '', 'past-events', '', '', '2020-04-23 15:53:06', '2020-04-23 15:53:06', '', 0, 'http://st-charles-county-veterans-museum.local/?page_id=44', 0, 'page', '', 0),
(45, 1, '2020-04-23 15:53:05', '2020-04-23 15:53:05', '', 'Past Events', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2020-04-23 15:53:05', '2020-04-23 15:53:05', '', 44, 'http://st-charles-county-veterans-museum.local/44-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2020-04-24 18:58:49', '2020-04-24 18:58:49', '<!-- wp:paragraph -->\n<p>Ralph Barrale wanted to see a Veterans Museum that would honor all of those Veterans who served our country, and especially those from St. Charles County. This was but another example of Ralph Barrale’s dedication to our servicemen and women and his desire to keep their memories in the forefront of the generations of today so that our Veterans will not be forgotten.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The museum opened in the spring of 2019. There you will find “Ralph’s Story” among others like his, who served our country, because Ralph felt</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>“NO ONE IS EVER GONE, AS LONG AS SOMEONE STILL HAS MEMORIES OF THEM”</p></blockquote>\n<!-- /wp:quote -->', 'Home', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2020-04-24 18:58:49', '2020-04-24 18:58:49', '', 24, 'http://st-charles-county-veterans-museum.local/24-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2020-04-24 19:00:22', '2020-04-24 19:00:22', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p></p></blockquote>\n<!-- /wp:quote -->', 'Home', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2020-04-24 19:00:22', '2020-04-24 19:00:22', '', 24, 'http://st-charles-county-veterans-museum.local/24-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2019-10-16 19:28:01', '2019-10-16 19:28:01', '<!-- wp:paragraph -->\n<p>Home Depot installs six new flag poles 10-16-19</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>On October 16th, the Home Depot St Charles store visited the St Charles County Veterans Museum. They installed six new flagpoles, mulch, rock, and built a flower bed. Libby Stevenson and her team at store #3009 secured a Home Depot grant for the project.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><em>\"Having the flags or emblems of the service in the front of the museum was the dream of Ralph Barrale Sr our founder,</em>\" says Jim Higgins Museum Board member.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\"<em>The Home Depot has been very generous in helping us since construction began in fall of 2018,\" Higgins Said.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>In addition to Home Depot, Pavestone (a vendor and stone distributor for Home Depot) has donated thousands of dollars in materials and installation.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\"<em>With Pavestone’s help, we created many flower beds throughout the property.&nbsp; They previously installed the memorial pavers in front of the flag poles and today they helped add the stone wall around the flagpole lights.&nbsp;</em>&nbsp;<em>Aaron Jenkins and Ty Sterthmon are the factory representatives for Pavestone.&nbsp; They have been very generous and helpful,\" Higgins said.</em></p>\n<!-- /wp:paragraph -->', 'Team Home Depot Assists St Charles County Veterans Museum', '', 'publish', 'open', 'open', '', 'team-home-depot-assists-st-charles-county-veterans-museum', '', '', '2020-04-24 19:28:35', '2020-04-24 19:28:35', '', 0, 'http://st-charles-county-veterans-museum.local/?p=48', 0, 'post', '', 0),
(49, 1, '2020-04-24 19:28:01', '2020-04-24 19:28:01', '<!-- wp:paragraph -->\n<p>Home Depot installs six new flag poles 10-16-19</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>On October 16th, the Home Depot St Charles store visited the St Charles County Veterans Museum. They installed six new flagpoles, mulch, rock, and built a flower bed. Libby Stevenson and her team at store #3009 secured a Home Depot grant for the project.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><em>\"Having the flags or emblems of the service in the front of the museum was the dream of Ralph Barrale Sr our founder,</em>\" says Jim Higgins Museum Board member.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\"<em>The Home Depot has been very generous in helping us since construction began in fall of 2018,\" Higgins Said.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>In addition to Home Depot, Pavestone (a vendor and stone distributor for Home Depot) has donated thousands of dollars in materials and installation.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\"<em>With Pavestone’s help, we created many flower beds throughout the property.&nbsp; They previously installed the memorial pavers in front of the flag poles and today they helped add the stone wall around the flagpole lights.&nbsp;</em>&nbsp;<em>Aaron Jenkins and Ty Sterthmon are the factory representatives for Pavestone.&nbsp; They have been very generous and helpful,\" Higgins said.</em></p>\n<!-- /wp:paragraph -->', 'Team Home Depot Assists St Charles County Veterans Museum', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2020-04-24 19:28:01', '2020-04-24 19:28:01', '', 48, 'http://st-charles-county-veterans-museum.local/48-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2019-09-30 19:30:00', '2019-09-30 19:30:00', '<!-- wp:paragraph -->\n<p>St Charles County Veterans Museum Ready for Fall</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The American Heritage Girls MO 3130 led by Michelle Purcell added a touch of fall decorations to the St Charles County Veterans Museum on Saturday.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The girls adopted a garden, added a few scarecrows, pumpkins, bulbs and mums. When they finished decorating, they raked leaves.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\"The community has really contributed to create a beautiful museum,\" says Jim Higgins, Museum Board Member.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\"Previously the girls built inspirational prayer benches and painted stones decorating the grounds. When you look at the museum and grounds, you quickly realize it is a community treasure. We\'ve had Cub Scouts, Eagle Scouts, Church Groups, Fort Zumwalt students, Lindenwood Students, and many other groups donate time,\" Higgins said.</p>\n<!-- /wp:paragraph -->', 'American Heritage Girls Decorate Veterans Museum', '', 'publish', 'open', 'open', '', 'american-heritage-girls-decorate-veterans-museum', '', '', '2020-04-24 19:30:42', '2020-04-24 19:30:42', '', 0, 'http://st-charles-county-veterans-museum.local/?p=50', 0, 'post', '', 0),
(51, 1, '2020-04-24 19:30:05', '2020-04-24 19:30:05', '<!-- wp:paragraph -->\n<p>St Charles County Veterans Museum Ready for Fall</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The American Heritage Girls MO 3130 led by Michelle Purcell added a touch of fall decorations to the St Charles County Veterans Museum on Saturday.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The girls adopted a garden, added a few scarecrows, pumpkins, bulbs and mums. When they finished decorating, they raked leaves.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\"The community has really contributed to create a beautiful museum,\" says Jim Higgins, Museum Board Member.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\"Previously the girls built inspirational prayer benches and painted stones decorating the grounds. When you look at the museum and grounds, you quickly realize it is a community treasure. We\'ve had Cub Scouts, Eagle Scouts, Church Groups, Fort Zumwalt students, Lindenwood Students, and many other groups donate time,\" Higgins said.</p>\n<!-- /wp:paragraph -->', 'American Heritage Girls Decorate Veterans Museum', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2020-04-24 19:30:05', '2020-04-24 19:30:05', '', 50, 'http://st-charles-county-veterans-museum.local/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2019-08-24 19:31:00', '2019-08-24 19:31:00', '<!-- wp:paragraph -->\n<p>Camping anyone?</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our overnight guests on October 18th was Cub Scout Pack 813 of O’Fallon. They pitched tents on the museum grounds and we had our first ever&nbsp;<em>Night at the Museum&nbsp;</em>Tour.&nbsp; We treated them to a museum scavenger hunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>They watched an outdoor movie and ate s’mores. Thank you to the City of O’Fallon Police Department K-9 unit for stopping by and visiting the campers. Vegas is O’Fallon’s newest K9. He is teamed with Officer Matt. The kids, parents and neighbors enjoyed meeting them.<br><br>In the morning the Cubs grabbed rakes and picked up leaves along the grounds.&nbsp; Sounds like the Cubs sleep well.&nbsp; Not sure about the adults.&nbsp;</p>\n<!-- /wp:paragraph -->', 'Cub Scout Pack 813 Camps at Museum', '', 'publish', 'open', 'open', '', 'cub-scout-pack-813-camps-at-museum', '', '', '2020-04-24 19:32:29', '2020-04-24 19:32:29', '', 0, 'http://st-charles-county-veterans-museum.local/?p=52', 0, 'post', '', 0),
(53, 1, '2020-04-24 19:31:40', '2020-04-24 19:31:40', '<!-- wp:paragraph -->\n<p>Camping anyone?</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our overnight guests on October 18th was Cub Scout Pack 813 of O’Fallon. They pitched tents on the museum grounds and we had our first ever&nbsp;<em>Night at the Museum&nbsp;</em>Tour.&nbsp; We treated them to a museum scavenger hunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>They watched an outdoor movie and ate s’mores. Thank you to the City of O’Fallon Police Department K-9 unit for stopping by and visiting the campers. Vegas is O’Fallon’s newest K9. He is teamed with Officer Matt. The kids, parents and neighbors enjoyed meeting them.<br><br>In the morning the Cubs grabbed rakes and picked up leaves along the grounds.&nbsp; Sounds like the Cubs sleep well.&nbsp; Not sure about the adults.&nbsp;</p>\n<!-- /wp:paragraph -->', 'Cub Scout Pack 813 Camps at Museum', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2020-04-24 19:31:40', '2020-04-24 19:31:40', '', 52, 'http://st-charles-county-veterans-museum.local/52-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2020-01-24 19:33:00', '2020-01-24 19:33:00', '<!-- wp:paragraph -->\n<p>Thank you to Michael Brophy who wrapped up his Eagle Scout Project this weekend at the museum.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Michael added the final touches on the Military Engineers Bridge. The Bridge is a tribute to Seabees and Combat Engineers. The sign was added to complete the project. The sign provides a brief history of each branch and tells the story of two historical figures. Marvin Shields is the only Seabee to win a Congressional Medal of Honor and James D. McRacken won the Distinguished Service Cross.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Come by and check out the grounds of the museum!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Thank you Michael and the entire Brophy Family.</p>\n<!-- /wp:paragraph -->', 'Military Engineers Bridge Finished', '', 'publish', 'open', 'open', '', 'military-engineers-bridge-finished', '', '', '2020-04-24 19:33:54', '2020-04-24 19:33:54', '', 0, 'http://st-charles-county-veterans-museum.local/?p=54', 0, 'post', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(55, 1, '2020-04-24 19:33:35', '2020-04-24 19:33:35', '<!-- wp:paragraph -->\n<p>Thank you to Michael Brophy who wrapped up his Eagle Scout Project this weekend at the museum.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Michael added the final touches on the Military Engineers Bridge. The Bridge is a tribute to Seabees and Combat Engineers. The sign was added to complete the project. The sign provides a brief history of each branch and tells the story of two historical figures. Marvin Shields is the only Seabee to win a Congressional Medal of Honor and James D. McRacken won the Distinguished Service Cross.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Come by and check out the grounds of the museum!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Thank you Michael and the entire Brophy Family.</p>\n<!-- /wp:paragraph -->', 'Military Engineers Bridge Finished', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2020-04-24 19:33:35', '2020-04-24 19:33:35', '', 54, 'http://st-charles-county-veterans-museum.local/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2020-02-12 19:35:00', '2020-02-12 19:35:00', '<!-- wp:paragraph -->\n<p>Today we were saddened to hear of the passing of Rose Barrale, wife of the late Ralph Barrale Sr.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Rose is preceded in death by her dear husband of 72 years, Ralph Barrale, Sr. The St. Charles County Veterans Museum was the dream of Ralph, and Rose was always by his side supporting his efforts. ,</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>She is also precdeded in death by her father, Joseph Busalaki, mother, Rose Pitti Busalaki, Twin Sister, Anna Marie Bognar, brother, John Busalaki, sister, Louise Stepler and Grandson, Eric Pluth.<br><br>She is survived by her daughter, Josephine Ann (Richard) Rice of Huntsville, Alabama and sons, Ralph Barrale of Wentzville and Lari (Debbie) Barrale of Cape Coral, Florida. 7 Grandchildren, 11 Great-Grandchildren and many nieces, nephews and friends.<br><br>Rose Marie raised her family in Florissant, and has been a resident of Lake St. Louis for over 40 years. Not only did she support Ralph in all of the work he did for Veteran’s here in St. Charles County, she was Chairwoman of the Lake St Louis Cookout Group, Member of the Lake St. Louis VFW Women’s Auxiliary, volunteer at the Green Lantern Senior Center, Volunteer at St. Patrick’s Church in Wentzville. She has been a loving mother, grandmother and great-grandmother, and will be missed by everyone who knew and loved her.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Rose visited the museum often, encouraging our team and thanking us for our hard work. She told us very often how pleased Ralph would be to see the museum.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>She will be dearly missed by all of us. We love you Rose!</p>\n<!-- /wp:paragraph -->', 'Rest in Peace, Rose Barrale', '', 'publish', 'open', 'open', '', 'rest-in-peace-rose-barrale', '', '', '2020-04-24 19:36:12', '2020-04-24 19:36:12', '', 0, 'http://st-charles-county-veterans-museum.local/?p=56', 0, 'post', '', 0),
(57, 1, '2020-04-24 19:35:37', '2020-04-24 19:35:37', '<!-- wp:paragraph -->\n<p>Today we were saddened to hear of the passing of Rose Barrale, wife of the late Ralph Barrale Sr.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Rose is preceded in death by her dear husband of 72 years, Ralph Barrale, Sr. The St. Charles County Veterans Museum was the dream of Ralph, and Rose was always by his side supporting his efforts. ,</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>She is also precdeded in death by her father, Joseph Busalaki, mother, Rose Pitti Busalaki, Twin Sister, Anna Marie Bognar, brother, John Busalaki, sister, Louise Stepler and Grandson, Eric Pluth.<br><br>She is survived by her daughter, Josephine Ann (Richard) Rice of Huntsville, Alabama and sons, Ralph Barrale of Wentzville and Lari (Debbie) Barrale of Cape Coral, Florida. 7 Grandchildren, 11 Great-Grandchildren and many nieces, nephews and friends.<br><br>Rose Marie raised her family in Florissant, and has been a resident of Lake St. Louis for over 40 years. Not only did she support Ralph in all of the work he did for Veteran’s here in St. Charles County, she was Chairwoman of the Lake St Louis Cookout Group, Member of the Lake St. Louis VFW Women’s Auxiliary, volunteer at the Green Lantern Senior Center, Volunteer at St. Patrick’s Church in Wentzville. She has been a loving mother, grandmother and great-grandmother, and will be missed by everyone who knew and loved her.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Rose visited the museum often, encouraging our team and thanking us for our hard work. She told us very often how pleased Ralph would be to see the museum.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>She will be dearly missed by all of us. We love you Rose!</p>\n<!-- /wp:paragraph -->', 'Rest in Peace, Rose Barrale', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2020-04-24 19:35:37', '2020-04-24 19:35:37', '', 56, 'http://st-charles-county-veterans-museum.local/56-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2020-02-24 19:41:00', '2020-02-24 19:41:00', '<!-- wp:paragraph -->\n<p>Tonight the St. Charles County Veterans Museum was honored to host the Winners of an Essay Contest from Assumption Elementary School sponsored by the St. Barnabas Men’s Club.&nbsp; The essay contest titled,&nbsp;<strong><em>What a Veteran Means to Me</em></strong>.&nbsp; First Place received a cash award for $100.00, second place $50.00 and third place $25.00 from the Men’s Club.&nbsp; Mayor Bill Hennessey and principal Dr. Pat Hensley were in attendance to make the presentations.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The essay contest was for the 7th and 8th grade classes.&nbsp; There were 87 essays entered in the contest.&nbsp; Congratulations to the winners and thanks to all students who turned in an essay!&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>3rd Place Mariah<br>A veteran is a person who has served in a military force, but to me that’s not all they do!&nbsp; To me, a veteran is a person with a brave heart, a kind spirit and courageous mind.&nbsp; Veterans are away from their families and friends for weeks and sometimes years, but they fight for our freedom, no matter the cost.&nbsp; It weren’t for veterans, America would not be the same!&nbsp; They go out on that battlefield, load their guns, and fight for us and our country.&nbsp; Some veterans might not even make it home and die alone, but they die with dignity and honor. &nbsp;Veterans inspire others and make the world a safe and better place.&nbsp; I’ve never had bullets fly by my head before, but I’ve experienced freedom because of the men and women who did.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2nd Place Cooper<br>Veterans are an inspiration to me.&nbsp; When I think about a Veteran, the first thing that comes to mind is a life saver.&nbsp; Someone who puts their life on the line to save someone else’s.&nbsp; I appreciate them most because of their courage.&nbsp; The pain frightens them, but they know what they are fighting for.&nbsp; A Veteran is my inspiration.&nbsp; They inspire me to keep moving forward and that anything is possible.&nbsp; They push me to do great things in life.&nbsp; To help someone in need, just like they do. A famous quote from Douglas MacArthur says, “The soldier above all prays for peace, for it is the soldier who must suffer and bear the deepest wounds and scars of war.”&nbsp; His quote is meaningful to me because it shows that if you put all your effort into what you care for you can achieve great things.&nbsp; Every year we honor Veterans for one day.&nbsp; On that day, we should honor them because a Veteran deserves a lot.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1st Place Mia<br>What does a Veteran mean to me?&nbsp; A Veteran is one who is wise, one who has served, one that has helped the nation grow.&nbsp; A veteran is one who is willing to sacrifice and do the impossible.&nbsp; Veterans are ones who honor, have courage, respect and persevere.&nbsp; Veterans are our heroes, they deserve our celebration and appreciation.&nbsp; They risked their lives just to save ours from the threats the world could bring.&nbsp; Although some are blessed enough to still be here today, they say the genuine heroes are those who didn’t return from the war.&nbsp; Remember Veterans, for they have made this nation proud.&nbsp;</p>\n<!-- /wp:paragraph -->', 'What a Veteran Means to Me', '', 'publish', 'open', 'open', '', 'what-a-veteran-means-to-me', '', '', '2020-04-24 19:41:51', '2020-04-24 19:41:51', '', 0, 'http://st-charles-county-veterans-museum.local/?p=58', 0, 'post', '', 0),
(59, 1, '2020-04-24 19:41:13', '2020-04-24 19:41:13', '<!-- wp:paragraph -->\n<p>Tonight the St. Charles County Veterans Museum was honored to host the Winners of an Essay Contest from Assumption Elementary School sponsored by the St. Barnabas Men’s Club.&nbsp; The essay contest titled,&nbsp;<strong><em>What a Veteran Means to Me</em></strong>.&nbsp; First Place received a cash award for $100.00, second place $50.00 and third place $25.00 from the Men’s Club.&nbsp; Mayor Bill Hennessey and principal Dr. Pat Hensley were in attendance to make the presentations.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The essay contest was for the 7th and 8th grade classes.&nbsp; There were 87 essays entered in the contest.&nbsp; Congratulations to the winners and thanks to all students who turned in an essay!&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>3rd Place Mariah<br>A veteran is a person who has served in a military force, but to me that’s not all they do!&nbsp; To me, a veteran is a person with a brave heart, a kind spirit and courageous mind.&nbsp; Veterans are away from their families and friends for weeks and sometimes years, but they fight for our freedom, no matter the cost.&nbsp; It weren’t for veterans, America would not be the same!&nbsp; They go out on that battlefield, load their guns, and fight for us and our country.&nbsp; Some veterans might not even make it home and die alone, but they die with dignity and honor. &nbsp;Veterans inspire others and make the world a safe and better place.&nbsp; I’ve never had bullets fly by my head before, but I’ve experienced freedom because of the men and women who did.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>2nd Place Cooper<br>Veterans are an inspiration to me.&nbsp; When I think about a Veteran, the first thing that comes to mind is a life saver.&nbsp; Someone who puts their life on the line to save someone else’s.&nbsp; I appreciate them most because of their courage.&nbsp; The pain frightens them, but they know what they are fighting for.&nbsp; A Veteran is my inspiration.&nbsp; They inspire me to keep moving forward and that anything is possible.&nbsp; They push me to do great things in life.&nbsp; To help someone in need, just like they do. A famous quote from Douglas MacArthur says, “The soldier above all prays for peace, for it is the soldier who must suffer and bear the deepest wounds and scars of war.”&nbsp; His quote is meaningful to me because it shows that if you put all your effort into what you care for you can achieve great things.&nbsp; Every year we honor Veterans for one day.&nbsp; On that day, we should honor them because a Veteran deserves a lot.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>1st Place Mia<br>What does a Veteran mean to me?&nbsp; A Veteran is one who is wise, one who has served, one that has helped the nation grow.&nbsp; A veteran is one who is willing to sacrifice and do the impossible.&nbsp; Veterans are ones who honor, have courage, respect and persevere.&nbsp; Veterans are our heroes, they deserve our celebration and appreciation.&nbsp; They risked their lives just to save ours from the threats the world could bring.&nbsp; Although some are blessed enough to still be here today, they say the genuine heroes are those who didn’t return from the war.&nbsp; Remember Veterans, for they have made this nation proud.&nbsp;</p>\n<!-- /wp:paragraph -->', 'What a Veteran Means to Me', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2020-04-24 19:41:13', '2020-04-24 19:41:13', '', 58, 'http://st-charles-county-veterans-museum.local/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2020-04-24 19:42:20', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-04-24 19:42:20', '0000-00-00 00:00:00', '', 0, 'http://st-charles-county-veterans-museum.local/?p=60', 0, 'post', '', 0),
(61, 1, '2020-04-24 19:43:22', '2020-04-24 19:43:22', 'St Charles County Mayors Charity Ball will be held on Saturday, March 21!\r\n\r\nFor more information, click below to download the PDF flyer.\r\n\r\n&nbsp;\r\n\r\nProceeds from the event will help support the St. Charles County Veterans Museum.', 'St. Charles County Mayors Charity Ball 2020', '', 'publish', 'closed', 'closed', '', 'st-charles-county-mayors-charity-ball-2020-2', '', '', '2020-04-27 21:25:52', '2020-04-27 21:25:52', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=61', 0, 'event', '', 0),
(62, 1, '2020-04-27 21:01:19', '2020-04-27 21:01:19', 'FUTURE EVENT', 'Future Event', '', 'trash', 'closed', 'closed', '', 'future-event__trashed', '', '', '2020-04-27 21:03:56', '2020-04-27 21:03:56', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=62', 0, 'event', '', 0),
(63, 1, '2020-04-27 21:35:04', '2020-04-27 21:35:04', 'dfvdgvg', 'Future', '', 'trash', 'closed', 'closed', '', 'future__trashed', '', '', '2020-04-27 21:44:45', '2020-04-27 21:44:45', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=63', 0, 'event', '', 0),
(64, 1, '2020-04-27 21:40:32', '2020-04-27 21:40:32', 'werwer', 'Future II', '', 'trash', 'closed', 'closed', '', 'future-ii__trashed', '', '', '2020-04-27 21:44:43', '2020-04-27 21:44:43', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=64', 0, 'event', '', 0),
(65, 1, '2020-04-27 22:03:42', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2020-04-27 22:03:42', '0000-00-00 00:00:00', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&p=65', 0, 'event', '', 0),
(66, 1, '2020-04-27 22:05:03', '2020-04-27 22:05:03', '', 'Future event 1', '', 'trash', 'closed', 'closed', '', 'future-event-1__trashed', '', '', '2020-04-27 22:07:46', '2020-04-27 22:07:46', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=66', 0, 'event', '', 0),
(67, 1, '2020-04-27 22:15:10', '2020-04-27 22:15:10', '123123', 'Future thing', '', 'trash', 'closed', 'closed', '', 'future-thing__trashed', '', '', '2020-04-27 22:15:23', '2020-04-27 22:15:23', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=67', 0, 'event', '', 0),
(68, 1, '2020-04-27 23:06:34', '2020-04-27 23:06:34', '', 'future', '', 'trash', 'closed', 'closed', '', 'future__trashed-2', '', '', '2020-04-27 23:06:45', '2020-04-27 23:06:45', '', 0, 'http://st-charles-county-veterans-museum.local/?post_type=event&#038;p=68', 0, 'event', '', 0),
(69, 1, '2020-04-28 20:47:48', '2020-04-28 20:47:48', '<!-- wp:paragraph -->\n<p>Donate page </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>A museum that honors the story of every veteran that has ever lived in St. Charles County.&nbsp; That’s a tall order! We need your help!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The <em>St. Charles County Veterans Museum is a 501C.3 Non-Profit</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>To make a monetary donation to help support the museum please click on the link below.</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are looking to donate items to the St. Charles County Veterans Museum… Every one of us has a family member, a friend, a loved one who served in the military and many of us have memorabilia from their service to our country.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We are not certain we can part with it, but we don’t want to see it lost or forgotten. Wouldn’t it be wonderful if it could be shared with other veterans, and see it be part of the story with other St. Charles County Veterans. Maybe your family was born in St. Charles County but moved away, or they only retired here? If that veterans ever lived in St. Charles County, this museum is the place for his memories. If you would like to discuss how donate items to the museum, or if you want to share a story with us, please use the box below.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The St. Charles County Veterans Commission Committee opened the SAINT CHARLES COUNTY VETERANS MUSEUM IN THE SPRING OF 2019.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are interested in donating items, please contact us by email at&nbsp;<a href=\"mailto:%20info@stcharlescountyveteransmuseum.com\">info@stcharlescountyveteransmuseum.com</a><br>or call us at 636-294-2657 today.</p>\n<!-- /wp:paragraph -->', 'Donate', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2020-04-28 20:47:48', '2020-04-28 20:47:48', '', 9, 'http://st-charles-county-veterans-museum.local/9-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2020-04-28 20:48:17', '2020-04-28 20:48:17', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>A museum that honors the story of every veteran that has ever lived in St. Charles County.&nbsp; That’s a tall order! We need your help!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The <em>St. Charles County Veterans Museum is a 501C.3 Non-Profit</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>To make a monetary donation to help support the museum please click on the link below.</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are looking to donate items to the St. Charles County Veterans Museum… Every one of us has a family member, a friend, a loved one who served in the military and many of us have memorabilia from their service to our country.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We are not certain we can part with it, but we don’t want to see it lost or forgotten. Wouldn’t it be wonderful if it could be shared with other veterans, and see it be part of the story with other St. Charles County Veterans. Maybe your family was born in St. Charles County but moved away, or they only retired here? If that veterans ever lived in St. Charles County, this museum is the place for his memories. If you would like to discuss how donate items to the museum, or if you want to share a story with us, please use the box below.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The St. Charles County Veterans Commission Committee opened the SAINT CHARLES COUNTY VETERANS MUSEUM IN THE SPRING OF 2019.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are interested in donating items, please contact us by email at&nbsp;<a href=\"mailto:%20info@stcharlescountyveteransmuseum.com\">info@stcharlescountyveteransmuseum.com</a><br>or call us at 636-294-2657 today.</p>\n<!-- /wp:paragraph -->', 'Donate', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2020-04-28 20:48:17', '2020-04-28 20:48:17', '', 9, 'http://st-charles-county-veterans-museum.local/9-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2020-04-28 20:50:10', '2020-04-28 20:50:10', '<!-- wp:paragraph -->\n<p>Below are some pictures of our gallery and displays. We are always on the lookout for new items to display from St. Charles County Veterans. The museum also works to rotate items to have different displays throughout the year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to become a sponsor of a display as well, your name and/or business logo will be prominently displayed.&nbsp;<a href=\"http://stcharlescountyveteransmuseum.org/contact/index.html\">Contact us today</a>!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Gallery', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2020-04-28 20:50:10', '2020-04-28 20:50:10', '', 11, 'http://st-charles-county-veterans-museum.local/11-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2020-04-28 20:50:37', '2020-04-28 20:50:37', '<!-- wp:paragraph -->\n<p><strong>Below are some videos we have compiled! Watch and enjoy!</strong></p>\n<!-- /wp:paragraph -->', 'Videos', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2020-04-28 20:50:37', '2020-04-28 20:50:37', '', 7, 'http://st-charles-county-veterans-museum.local/7-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2020-04-28 20:52:24', '2020-04-28 20:52:24', '<!-- wp:paragraph -->\n<p>Would you like to get involved with some of the most dedicated people in St. Charles County?<strong></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to join the volunteers working to make the St. Charles County Veterans Museum a reality, then we would like to hear from you! You don’t need to be a Veteran, we love Patriots too!&nbsp; Whether it is stuffing envelopes, building exhibits, helping with the Gift Shop, talking to groups, working on the gardens, or maybe you have ideas we haven’t even thought of yet! We want to hear from you!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You can either email us at&nbsp;<a href=\"mailto:info@stcharlescountyveteransmuseum.com\" target=\"_blank\" rel=\"noreferrer noopener\">info@stcharlescountyveteransmuseum.com</a>&nbsp;or call 636-294-2657 or fill out the form below!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Volunteers', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-04-28 20:52:24', '2020-04-28 20:52:24', '', 17, 'http://st-charles-county-veterans-museum.local/17-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2020-04-28 20:53:33', '2020-04-28 20:53:33', '<!-- wp:paragraph -->\n<p>Plans for a museum that honored all Veterans was a dream of Ralph Barrale (1924-2018) when he gathered a planning team, and secured a lease from the City of O’Fallon, Missouri at 410 East Elm Street.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The former City Annex has been transformed by a great team of volunteers. This 501C.3 not-for-profit Museum will feature the stories of all Veterans that ever served and who ever lived in St. Charles County.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Their mission is “<em>Inspiring, informing and engaging the residents of St. Charles County to honor the memories of County Veterans who served the United States of America with patriotic valor</em>” and creating a museum experience for young and old, veterans and patriots that truly honors our veterans. Here our military community will feel welcome, our children and grandchildren will engage, and our community connect. We welcome you and invite you to participate and join us in our mission.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Would you like to hear more? Please contact us by calling 636-294-2657 or email us at&nbsp;<a href=\"mailto:info@stcharlescountyveteransmuseum.com\" target=\"_blank\" rel=\"noreferrer noopener\">info@stcharlescountyveteransmuseum.com</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We welcome any size of contribution and will provide an acknowledgement and opportunity for everyone to show how they have helped make this museum a reality.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Special thank you to Home Depot for the help in making the St. Charles County Veterans Museum a reality!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Sponsors', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2020-04-28 20:53:33', '2020-04-28 20:53:33', '', 13, 'http://st-charles-county-veterans-museum.local/13-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2020-04-28 20:54:55', '2020-04-28 20:54:55', '<!-- wp:paragraph -->\n<p><strong>Special thank you to Home Depot for the help in making the St. Charles County Veterans Museum a reality!</strong></p>\n<!-- /wp:paragraph -->', 'Special Thank You!', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2020-04-28 20:54:55', '2020-04-28 20:54:55', '', 22, 'http://st-charles-county-veterans-museum.local/22-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2020-04-28 21:10:14', '2020-04-28 21:10:14', '<!-- wp:paragraph -->\n<p>Sponsorship packages</p>\n<!-- /wp:paragraph -->', 'Packages', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2020-04-28 21:10:14', '2020-04-28 21:10:14', '', 20, 'http://st-charles-county-veterans-museum.local/20-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2020-04-28 22:53:57', '2020-04-28 22:53:57', '<!-- wp:paragraph -->\n<p>Sponsorship packages</p>\n<!-- /wp:paragraph -->', 'Packages', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2020-04-28 22:53:57', '2020-04-28 22:53:57', '', 20, 'http://st-charles-county-veterans-museum.local/20-revision-v1/', 0, 'revision', '', 0),
(78, 1, '2020-04-28 23:02:36', '2020-04-28 23:02:36', '<!-- wp:paragraph -->\n<p><strong>Special thank you to Home Depot for the help in making the St. Charles County Veterans Museum a reality!</strong></p>\n<!-- /wp:paragraph -->', 'Thank You!', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2020-04-28 23:02:36', '2020-04-28 23:02:36', '', 22, 'http://st-charles-county-veterans-museum.local/22-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2020-04-28 23:03:33', '2020-04-28 23:03:33', '', 'home-depot', '', 'inherit', 'open', 'closed', '', 'home-depot', '', '', '2020-04-28 23:03:33', '2020-04-28 23:03:33', '', 22, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/home-depot.png', 0, 'attachment', 'image/png', 0),
(80, 1, '2020-04-28 23:03:41', '2020-04-28 23:03:41', '<!-- wp:paragraph -->\n<p><strong>Special thank you to Home Depot for the help in making the St. Charles County Veterans Museum a reality!</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"align\":\"center\",\"id\":79,\"sizeSlug\":\"large\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/home-depot.png\" alt=\"\" class=\"wp-image-79\"/></figure></div>\n<!-- /wp:image -->', 'Thank You!', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2020-04-28 23:03:41', '2020-04-28 23:03:41', '', 22, 'http://st-charles-county-veterans-museum.local/22-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2020-04-28 23:04:42', '2020-04-28 23:04:42', '<!-- wp:paragraph -->\n<p><strong>Special thank you to Home Depot for the help in making the St. Charles County Veterans Museum a reality!</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"align\":\"center\",\"id\":79,\"sizeSlug\":\"large\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/home-depot.png\" alt=\"\" class=\"wp-image-79\"/></figure></div>\n<!-- /wp:image -->', 'Thank You!', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2020-04-28 23:04:42', '2020-04-28 23:04:42', '', 22, 'http://st-charles-county-veterans-museum.local/22-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2020-04-28 23:05:13', '2020-04-28 23:05:13', '<!-- wp:paragraph -->\n<p>Plans for a museum that honored all Veterans was a dream of Ralph Barrale (1924-2018) when he gathered a planning team, and secured a lease from the City of O’Fallon, Missouri at 410 East Elm Street.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The former City Annex has been transformed by a great team of volunteers. This 501C.3 not-for-profit Museum will feature the stories of all Veterans that ever served and who ever lived in St. Charles County.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Their mission is “<em>Inspiring, informing and engaging the residents of St. Charles County to honor the memories of County Veterans who served the United States of America with patriotic valor</em>” and creating a museum experience for young and old, veterans and patriots that truly honors our veterans. Here our military community will feel welcome, our children and grandchildren will engage, and our community connect. We welcome you and invite you to participate and join us in our mission.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Would you like to hear more? Please contact us by calling 636-294-2657 or email us at&nbsp;<a href=\"mailto:info@stcharlescountyveteransmuseum.com\" target=\"_blank\" rel=\"noreferrer noopener\">info@stcharlescountyveteransmuseum.com</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We welcome any size of contribution and will provide an acknowledgement and opportunity for everyone to show how they have helped make this museum a reality.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Special thank you to Home Depot for the help in making the St. Charles County Veterans Museum a reality!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Sponsors', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2020-04-28 23:05:13', '2020-04-28 23:05:13', '', 13, 'http://st-charles-county-veterans-museum.local/13-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2020-04-28 23:05:54', '2020-04-28 23:05:54', '<!-- wp:paragraph -->\n<p>Sponsorship packages</p>\n<!-- /wp:paragraph -->', 'Packages', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2020-04-28 23:05:54', '2020-04-28 23:05:54', '', 20, 'http://st-charles-county-veterans-museum.local/20-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2020-04-29 04:01:25', '2020-04-29 04:01:25', '', 'gallery1', '', 'inherit', 'open', 'closed', '', 'gallery1', '', '', '2020-04-29 04:01:25', '2020-04-29 04:01:25', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1.png', 0, 'attachment', 'image/png', 0),
(86, 1, '2020-04-29 04:01:27', '2020-04-29 04:01:27', '', 'gallery2', '', 'inherit', 'open', 'closed', '', 'gallery2', '', '', '2020-04-29 04:01:27', '2020-04-29 04:01:27', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2.png', 0, 'attachment', 'image/png', 0),
(87, 1, '2020-04-29 04:01:29', '2020-04-29 04:01:29', '', 'gallery3', '', 'inherit', 'open', 'closed', '', 'gallery3', '', '', '2020-04-29 04:01:29', '2020-04-29 04:01:29', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3.png', 0, 'attachment', 'image/png', 0),
(88, 1, '2020-04-29 04:01:30', '2020-04-29 04:01:30', '', 'gallery4', '', 'inherit', 'open', 'closed', '', 'gallery4', '', '', '2020-04-29 04:01:30', '2020-04-29 04:01:30', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4.png', 0, 'attachment', 'image/png', 0),
(89, 1, '2020-04-29 04:01:37', '2020-04-29 04:01:37', '<!-- wp:paragraph -->\n<p>Below are some pictures of our gallery and displays. We are always on the lookout for new items to display from St. Charles County Veterans. The museum also works to rotate items to have different displays throughout the year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to become a sponsor of a display as well, your name and/or business logo will be prominently displayed.&nbsp;<a href=\"http://stcharlescountyveteransmuseum.org/contact/index.html\">Contact us today</a>!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"ids\":[85,86,87,88]} -->\n<figure class=\"wp-block-gallery columns-3 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1.png\" alt=\"\" data-id=\"85\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1.png\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery1/\" class=\"wp-image-85\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2.png\" alt=\"\" data-id=\"86\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2.png\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery2/\" class=\"wp-image-86\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3.png\" alt=\"\" data-id=\"87\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3.png\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery3/\" class=\"wp-image-87\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4.png\" alt=\"\" data-id=\"88\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4.png\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery4/\" class=\"wp-image-88\"/></figure></li></ul></figure>\n<!-- /wp:gallery -->', 'Gallery', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2020-04-29 04:01:37', '2020-04-29 04:01:37', '', 11, 'http://st-charles-county-veterans-museum.local/11-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2020-04-29 04:05:40', '2020-04-29 04:05:40', '<!-- wp:paragraph -->\n<p>Below are some pictures of our gallery and displays. We are always on the lookout for new items to display from St. Charles County veterans. The museum also works to rotate items to have different displays throughout the year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to become a sponsor of a display as well, your name and/or business logo will be prominently displayed.&nbsp;<a href=\"http://stcharlescountyveteransmuseum.org/contact/index.html\">Contact us today</a>!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"ids\":[88,85,86,87],\"columns\":2,\"align\":\"center\"} -->\n<figure class=\"wp-block-gallery aligncenter columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4.png\" alt=\"\" data-id=\"88\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4.png\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery4/\" class=\"wp-image-88\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1.png\" alt=\"\" data-id=\"85\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1.png\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery1/\" class=\"wp-image-85\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2.png\" alt=\"\" data-id=\"86\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2.png\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery2/\" class=\"wp-image-86\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3.png\" alt=\"\" data-id=\"87\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3.png\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery3/\" class=\"wp-image-87\"/></figure></li></ul></figure>\n<!-- /wp:gallery -->', 'Gallery', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2020-04-29 04:05:40', '2020-04-29 04:05:40', '', 11, 'http://st-charles-county-veterans-museum.local/11-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2020-04-29 04:06:39', '2020-04-29 04:06:39', '', 'MVIMG_20200425_115009', '', 'inherit', 'open', 'closed', '', 'mvimg_20200425_115009', '', '', '2020-04-29 04:06:39', '2020-04-29 04:06:39', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_115009.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 1, '2020-04-29 04:06:57', '2020-04-29 04:06:57', '', 'MVIMG_20200425_112821', '', 'inherit', 'open', 'closed', '', 'mvimg_20200425_112821', '', '', '2020-04-29 04:06:57', '2020-04-29 04:06:57', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112821.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2020-04-29 04:07:08', '2020-04-29 04:07:08', '', 'MVIMG_20200425_112008', '', 'inherit', 'open', 'closed', '', 'mvimg_20200425_112008', '', '', '2020-04-29 04:07:08', '2020-04-29 04:07:08', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112008.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 1, '2020-04-29 04:07:41', '2020-04-29 04:07:41', '', 'MVIMG_20200425_112349', '', 'inherit', 'open', 'closed', '', 'mvimg_20200425_112349', '', '', '2020-04-29 04:07:41', '2020-04-29 04:07:41', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112349.jpg', 0, 'attachment', 'image/jpeg', 0),
(97, 1, '2020-04-29 04:07:46', '2020-04-29 04:07:46', '<!-- wp:paragraph -->\n<p>Below are some pictures of our gallery and displays. We are always on the lookout for new items to display from St. Charles County veterans. The museum also works to rotate items to have different displays throughout the year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to become a sponsor of a display as well, your name and/or business logo will be prominently displayed.&nbsp;<a href=\"http://stcharlescountyveteransmuseum.org/contact/index.html\">Contact us today</a>!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"ids\":[88,85,86,87,92,93,94,null],\"columns\":2,\"align\":\"center\"} -->\n<figure class=\"wp-block-gallery aligncenter columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4.png\" alt=\"\" data-id=\"88\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery4/\" class=\"wp-image-88\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1.png\" alt=\"\" data-id=\"85\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery1/\" class=\"wp-image-85\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2.png\" alt=\"\" data-id=\"86\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery2/\" class=\"wp-image-86\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3.png\" alt=\"\" data-id=\"87\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery3/\" class=\"wp-image-87\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_115009-1024x768.jpg\" alt=\"\" data-id=\"92\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_115009/\" class=\"wp-image-92\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112821-1024x768.jpg\" alt=\"\" data-id=\"93\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112821/\" class=\"wp-image-93\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112008-1024x768.jpg\" alt=\"\" data-id=\"94\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112008/\" class=\"wp-image-94\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"blob:http://st-charles-county-veterans-museum.local/3727919b-6608-4f70-ad7e-4959e2b26537\"/></figure></li></ul></figure>\n<!-- /wp:gallery -->', 'Gallery', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2020-04-29 04:07:46', '2020-04-29 04:07:46', '', 11, 'http://st-charles-county-veterans-museum.local/11-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2020-04-29 04:08:30', '2020-04-29 04:08:30', '', 'MVIMG_20200425_111710', '', 'inherit', 'open', 'closed', '', 'mvimg_20200425_111710', '', '', '2020-04-29 04:08:30', '2020-04-29 04:08:30', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_111710.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2020-04-29 04:08:35', '2020-04-29 04:08:35', '<!-- wp:paragraph -->\n<p>Below are some pictures of our gallery and displays. We are always on the lookout for new items to display from St. Charles County veterans. The museum also works to rotate items to have different displays throughout the year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to become a sponsor of a display as well, your name and/or business logo will be prominently displayed.&nbsp;<a href=\"http://stcharlescountyveteransmuseum.org/contact/index.html\">Contact us today</a>!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"ids\":[88,85,86,87,92,93,94,96,null,null],\"columns\":2,\"align\":\"center\"} -->\n<figure class=\"wp-block-gallery aligncenter columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4.png\" alt=\"\" data-id=\"88\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery4/\" class=\"wp-image-88\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1.png\" alt=\"\" data-id=\"85\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery1/\" class=\"wp-image-85\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2.png\" alt=\"\" data-id=\"86\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery2/\" class=\"wp-image-86\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3.png\" alt=\"\" data-id=\"87\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery3/\" class=\"wp-image-87\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_115009-1024x768.jpg\" alt=\"\" data-id=\"92\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_115009/\" class=\"wp-image-92\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112821-1024x768.jpg\" alt=\"\" data-id=\"93\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112821/\" class=\"wp-image-93\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112008-1024x768.jpg\" alt=\"\" data-id=\"94\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112008/\" class=\"wp-image-94\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112349-1024x768.jpg\" alt=\"\" data-id=\"96\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112349/\" class=\"wp-image-96\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"blob:http://st-charles-county-veterans-museum.local/813b9fda-79cf-4731-af53-3b5f517e1402\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"blob:http://st-charles-county-veterans-museum.local/4f09a9e1-09a6-47f9-9ce3-5201b2341223\"/></figure></li></ul></figure>\n<!-- /wp:gallery -->', 'Gallery', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2020-04-29 04:08:35', '2020-04-29 04:08:35', '', 11, 'http://st-charles-county-veterans-museum.local/11-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2020-04-29 04:08:41', '2020-04-29 04:08:41', '', 'MVIMG_20200425_112520', '', 'inherit', 'open', 'closed', '', 'mvimg_20200425_112520', '', '', '2020-04-29 04:08:41', '2020-04-29 04:08:41', '', 11, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112520.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(102, 1, '2020-04-29 04:10:59', '2020-04-29 04:10:59', '<!-- wp:paragraph -->\n<p>Below are some pictures of our gallery and displays. We are always on the lookout for new items to display from St. Charles County veterans. The museum also works to rotate items to have different displays throughout the year.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to become a sponsor of a display as well, your name and/or business logo will be prominently displayed.&nbsp;<a href=\"http://stcharlescountyveteransmuseum.org/contact/index.html\">Contact us today</a>!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"ids\":[88,85,86,87,92,93,94,96,98,100],\"columns\":2,\"align\":\"center\"} -->\n<figure class=\"wp-block-gallery aligncenter columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery4-300x189.png\" alt=\"\" data-id=\"88\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery4/\" class=\"wp-image-88\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery1-300x189.png\" alt=\"\" data-id=\"85\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery1/\" class=\"wp-image-85\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery2-300x189.png\" alt=\"\" data-id=\"86\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery2/\" class=\"wp-image-86\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/gallery3-300x189.png\" alt=\"\" data-id=\"87\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/gallery3/\" class=\"wp-image-87\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_115009-1024x768.jpg\" alt=\"\" data-id=\"92\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_115009/\" class=\"wp-image-92\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112821-1024x768.jpg\" alt=\"\" data-id=\"93\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112821/\" class=\"wp-image-93\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112008-1024x768.jpg\" alt=\"\" data-id=\"94\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112008/\" class=\"wp-image-94\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112349-1024x768.jpg\" alt=\"\" data-id=\"96\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112349/\" class=\"wp-image-96\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_111710-1024x768.jpg\" alt=\"\" data-id=\"98\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_111710-scaled.jpg\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_111710/\" class=\"wp-image-98\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112520-1024x768.jpg\" alt=\"\" data-id=\"100\" data-full-url=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/MVIMG_20200425_112520-scaled.jpg\" data-link=\"http://st-charles-county-veterans-museum.local/gallery/mvimg_20200425_112520/\" class=\"wp-image-100\"/></figure></li></ul></figure>\n<!-- /wp:gallery -->', 'Gallery', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2020-04-29 04:10:59', '2020-04-29 04:10:59', '', 11, 'http://st-charles-county-veterans-museum.local/11-revision-v1/', 0, 'revision', '', 0),
(103, 1, '2020-04-29 04:16:55', '2020-04-29 04:16:55', '', 'volunteer', '', 'inherit', 'open', 'closed', '', 'volunteer', '', '', '2020-04-29 04:16:55', '2020-04-29 04:16:55', '', 17, 'http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/volunteer.png', 0, 'attachment', 'image/png', 0),
(104, 1, '2020-04-29 04:17:01', '2020-04-29 04:17:01', '<!-- wp:paragraph -->\n<p>Would you like to get involved with some of the most dedicated people in St. Charles County?<strong></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to join the volunteers working to make the St. Charles County Veterans Museum a reality, then we would like to hear from you! You don’t need to be a Veteran, we love Patriots too!&nbsp; Whether it is stuffing envelopes, building exhibits, helping with the Gift Shop, talking to groups, working on the gardens, or maybe you have ideas we haven’t even thought of yet! We want to hear from you!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You can either email us at&nbsp;<a href=\"mailto:info@stcharlescountyveteransmuseum.com\" target=\"_blank\" rel=\"noreferrer noopener\">info@stcharlescountyveteransmuseum.com</a>&nbsp;or call 636-294-2657 or fill out the form below!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":103,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/volunteer.png\" alt=\"\" class=\"wp-image-103\"/></figure>\n<!-- /wp:image -->', 'Volunteers', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-04-29 04:17:01', '2020-04-29 04:17:01', '', 17, 'http://st-charles-county-veterans-museum.local/17-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2020-04-29 04:54:18', '2020-04-29 04:54:18', '<!-- wp:paragraph -->\n<p>Would you like to get involved with some of the most dedicated people in St. Charles County?<strong></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you would like to join the volunteers working to make the St. Charles County Veterans Museum a reality, then we would like to hear from you! You don’t need to be a Veteran, we love Patriots too!&nbsp; Whether it is stuffing envelopes, building exhibits, helping with the Gift Shop, talking to groups, working on the gardens, or maybe you have ideas we haven’t even thought of yet! We want to hear from you!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You can either email us at&nbsp;<a href=\"mailto:info@stcharlescountyveteransmuseum.com\" target=\"_blank\" rel=\"noreferrer noopener\">info@stcharlescountyveteransmuseum.com</a>&nbsp;or call 636-294-2657 or fill out the form below!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":103,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://st-charles-county-veterans-museum.local/wp-content/uploads/2020/04/volunteer.png\" alt=\"\" class=\"wp-image-103\"/></figure>\n<!-- /wp:image -->', 'Volunteers', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-04-29 04:54:18', '2020-04-29 04:54:18', '', 17, 'http://st-charles-county-veterans-museum.local/17-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2020-04-29 05:00:40', '2020-04-29 05:00:40', '<!-- wp:paragraph -->\n<p><strong>Below are some videos we have compiled! Watch and enjoy!</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:core-embed/youtube {\"url\":\"https://www.youtube.com/watch?v=KiCKlzn4XU8\\u0026feature=emb_logo\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed-youtube wp-block-embed is-type-video is-provider-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=KiCKlzn4XU8&amp;feature=emb_logo\n</div></figure>\n<!-- /wp:core-embed/youtube -->\n\n<!-- wp:core-embed/youtube {\"url\":\"https://www.youtube.com/watch?v=nS9zt9xMHCM\\u0026feature=emb_logo\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed-youtube wp-block-embed is-type-video is-provider-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=nS9zt9xMHCM&amp;feature=emb_logo\n</div></figure>\n<!-- /wp:core-embed/youtube -->', 'Videos', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2020-04-29 05:00:40', '2020-04-29 05:00:40', '', 7, 'http://st-charles-county-veterans-museum.local/7-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2020-04-29 05:03:05', '2020-04-29 05:03:05', '<!-- wp:paragraph -->\n<p><strong>Below are some videos we have compiled! Watch and enjoy!</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:core-embed/youtube {\"url\":\"https://www.youtube.com/watch?v=KiCKlzn4XU8\\u0026feature=emb_logo\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed-youtube wp-block-embed is-type-video is-provider-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=KiCKlzn4XU8&amp;feature=emb_logo\n</div></figure>\n<!-- /wp:core-embed/youtube --></div></div>\n<!-- /wp:group --></div></div>\n<!-- /wp:group -->\n\n<!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"></div></div>\n<!-- /wp:group --></div></div>\n<!-- /wp:group -->\n\n<!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:core-embed/youtube {\"url\":\"https://www.youtube.com/watch?v=nS9zt9xMHCM\\u0026feature=emb_logo\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed-youtube wp-block-embed is-type-video is-provider-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=nS9zt9xMHCM&amp;feature=emb_logo\n</div></figure>\n<!-- /wp:core-embed/youtube --></div></div>\n<!-- /wp:group -->', 'Videos', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2020-04-29 05:03:05', '2020-04-29 05:03:05', '', 7, 'http://st-charles-county-veterans-museum.local/7-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'News', 'news', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(29, 2, 0),
(48, 1, 0),
(50, 1, 0),
(52, 1, 0),
(54, 1, 0),
(56, 1, 0),
(58, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 6),
(2, 2, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'luke'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"30e8dcc42e6c465d5ba0c9a139669178ee928466e57d2cb93e48b9309d70ca87\";a:4:{s:10:\"expiration\";i:1588387175;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36\";s:5:\"login\";i:1588214375;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '43'),
(18, 1, 'closedpostboxes_event', 'a:0:{}'),
(19, 1, 'metaboxhidden_event', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(20, 1, 'closedpostboxes_post', 'a:0:{}'),
(21, 1, 'metaboxhidden_post', 'a:0:{}'),
(22, 1, 'closedpostboxes_page', 'a:0:{}'),
(23, 1, 'metaboxhidden_page', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'luke', '$P$Bc1ldmE0j0DN3lJlzMYzEGzrPJJ2rx0', 'luke', 'gosnellwebdesign@gmail.com', 'http://st-charles-county-veterans-museum.local', '2020-04-07 23:04:21', '', 0, 'luke');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=458;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=435;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
